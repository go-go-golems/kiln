from dispatch import CorpusDispatch
DISPATCH=CorpusDispatch('/home/manuel/code/wesen/kiln/worktrees/passnet/ttmp/2026/10/30/KILN-005--reproduce-passnet-and-evaluate-reusable-kiln-compiler-transformations/sources/input-mutation-wave-patterns-v1/task-196/corpus',include_paths=['/usr/local/cuda/include'])
SINGLETONS=[0]
def kiln_generated(*args):
 inputs,identity=args[:-1],args[-1]
 result=DISPATCH(*inputs,specialization=(identity,))
 return result[0] if identity in SINGLETONS else result
