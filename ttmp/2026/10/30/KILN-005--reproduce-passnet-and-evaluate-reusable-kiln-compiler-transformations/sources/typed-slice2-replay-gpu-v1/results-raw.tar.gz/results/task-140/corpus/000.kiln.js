project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.reshape(N.slice(v0, 0, 1, 2), [1100]), [1100], "i64");
const v3 = N.expect(N.reshape(N.slice(v0, 0, 0, 1), [1100]), [1100], "i64");
const v4 = N.expect(N.indexSelect(v1, -2, v3), [1100, 16], "bf16");
return {out0: v2, out1: v4};
}, {v0: k.tensor([2, 1100], "i64"), v1: k.tensor([1000, 16], "bf16")});
