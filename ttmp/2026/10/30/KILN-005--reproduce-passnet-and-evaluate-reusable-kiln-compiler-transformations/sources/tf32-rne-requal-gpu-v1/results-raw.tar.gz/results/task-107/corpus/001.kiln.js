project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.conv2d(v0, v1, null, {"stride": [1, 1], "padding": [1, 1], "dilation": [1, 1], "groups": 1}), [32, 64, 112, 112], "f16");
const v3 = N.expect(N.maxPool2d(v2, {"kernel_size": [3, 3], "stride": [2, 2], "padding": [1, 1], "dilation": [1, 1], "ceil_mode": false, "return_indices": false}), [32, 64, 56, 56], "f16");
return {out0: v3};
}, {v0: k.tensor([32, 32, 112, 112], "f16"), v1: k.tensor([64, 32, 3, 3], "f16")});
