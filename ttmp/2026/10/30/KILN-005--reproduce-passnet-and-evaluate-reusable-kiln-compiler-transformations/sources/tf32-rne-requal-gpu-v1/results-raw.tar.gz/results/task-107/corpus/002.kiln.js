project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.conv2d(v0, v1, null, {"stride": [1, 1], "padding": [1, 1], "dilation": [1, 1], "groups": 1}), [128, 64, 128, 128], "f32");
const v3 = N.expect(N.maxPool2d(v2, {"kernel_size": [3, 3], "stride": [2, 2], "padding": [1, 1], "dilation": [1, 1], "ceil_mode": false, "return_indices": false}), [128, 64, 64, 64], "f32");
return {out0: v3};
}, {v0: k.tensor([128, 32, 128, 128], "f32"), v1: k.tensor([64, 32, 3, 3], "f32")});
