project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.cast(N.linear(N.cast(v0, "f32"), N.cast(v1, "f32"), null), "bf16"), [1, 64, 11008], "bf16");
const v4 = N.expect(N.mul(v2, v3), [1, 64, 11008], "bf16");
return {out0: v4};
}, {v0: k.tensor([1, 64, 2048], "bf16"), v1: k.tensor([11008, 2048], "bf16"), v2: k.tensor([1, 64, 11008], "bf16")});
