project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [4, 17, 64, 64], "f32");
const v4 = N.expect(N.mul(v3, 1.0), [4, 17, 64, 64], "f32");
const v5 = N.expect(N.reshape(v4, [4, 17, 4096]), [4, 17, 4096], "f32");
return {out0: v5};
}, {v0: k.tensor([4, 256, 64, 64], "f32"), v1: k.tensor([17, 256, 1, 1], "f32"), v2: k.tensor([17], "f32")});
