project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.conv2d(v0, v1, null, {"stride": [2, 2], "padding": [3, 3], "dilation": [1, 1], "groups": 1}), [1, 64, 192, 192], "bf16");
const v3 = N.expect(N.maxPool2d(v2, {"kernel_size": [3, 3], "stride": [2, 2], "padding": [1, 1], "dilation": [1, 1], "ceil_mode": false, "return_indices": false}), [1, 64, 96, 96], "bf16");
return {out0: v3};
}, {v0: k.tensor([1, 3, 384, 384], "bf16"), v1: k.tensor([64, 3, 7, 7], "bf16")});
