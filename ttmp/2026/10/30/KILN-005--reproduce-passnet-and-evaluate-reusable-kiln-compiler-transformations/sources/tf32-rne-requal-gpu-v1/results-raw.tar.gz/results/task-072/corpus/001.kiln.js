project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [32, 17, 64, 64], "bf16");
const v4 = N.expect(N.mul(v3, 1.0), [32, 17, 64, 64], "bf16");
const v5 = N.expect(N.reshape(v4, [32, 17, 4096]), [32, 17, 4096], "bf16");
return {out0: v5};
}, {v0: k.tensor([32, 256, 64, 64], "bf16"), v1: k.tensor([17, 256, 1, 1], "bf16"), v2: k.tensor([17], "bf16")});
