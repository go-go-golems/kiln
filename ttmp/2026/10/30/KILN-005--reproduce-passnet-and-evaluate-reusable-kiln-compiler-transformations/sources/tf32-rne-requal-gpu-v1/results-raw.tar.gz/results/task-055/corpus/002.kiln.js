project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.cast(N.sqrt(N.sum(N.mul(N.cast(v0, "f32"), N.cast(v0, "f32")), 1, true)), "bf16"), [2, 1], "bf16");
const v3 = N.expect(N.div(v0, v2), [2, 1152], "bf16");
const v4 = N.expect(N.transpose(v1, 0, -1), [1152, 1], "bf16");
const v5 = N.expect(v4, [1152, 1], "bf16");
return {out0: v3, out1: v5};
}, {v0: k.tensor([2, 1152], "bf16"), v1: k.tensor([1, 1152], "bf16")});
