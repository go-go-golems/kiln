project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.expect(N.cast(N.linear(N.cast(v0, "f32"), N.cast(v1, "f32"), null), "bf16"), [64, 17, 256], "bf16");
const v5 = N.expect(N.mul(v2, v3), [64, 17, 256], "bf16");
return {out0: v5, out1: v4};
}, {v0: k.tensor([64, 17, 512], "bf16"), v1: k.tensor([256, 512], "bf16"), v2: k.tensor([64, 17, 256], "bf16"), v3: k.tensor([256], "bf16")});
