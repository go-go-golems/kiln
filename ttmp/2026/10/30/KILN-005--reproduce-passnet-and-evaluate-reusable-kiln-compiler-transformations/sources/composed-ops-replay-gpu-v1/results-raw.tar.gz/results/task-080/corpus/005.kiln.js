project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.relu(v0), [32, 133, 16, 12], "bf16");
const v3 = N.expect(N.reshape(v2, [32, 133, 192]), [32, 133, 192], "bf16");
const v4 = N.expect(N.cast(N.sqrt(N.sum(N.mul(N.cast(v3, "f32"), N.cast(v3, "f32")), 2, true)), "bf16"), [32, 133, 1], "bf16");
const v5 = N.expect(N.mul(v4, 0.07216878364870322), [32, 133, 1], "bf16");
const v6 = N.expect(N.cast(N.select(N.lt(N.cast(v5, "f32"), N.cast(N.cast(N.const(1e-05, []), "bf16"), "f32")), N.cast(N.cast(N.const(1e-05, []), "bf16"), "f32"), N.cast(v5, "f32")), "bf16"), [32, 133, 1], "bf16");
const v7 = N.expect(N.div(v3, v6), [32, 133, 192], "bf16");
const v8 = N.expect(N.mul(v7, v1), [32, 133, 192], "bf16");
return {out0: v8, __mut0: v2};
}, {v0: k.tensor([32, 133, 16, 12], "bf16"), v1: k.tensor([1], "bf16")});
