project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.cast(N.reshape(N.matmul(N.reshape(N.transpose(N.transpose(N.cast(v0, "f32"), 1, 2), 2, 3), [64, 64, 64]), N.reshape(N.transpose(N.cast(v1, "f32"), 1, 2), [64, 64, 64])), [1, 64, 64, 64]), "f16"), [1, 64, 64, 64], "f16");
const v4 = N.expect(N.concat([v2, v3], -1), [1, 64, 64, 128], "f16");
const v5 = N.expect(N.cast(N.softmax(N.cast(v4, "f32"), 3), "f16"), [1, 64, 64, 128], "f16");
const v6 = N.expect(N.reshape(N.slice(v5, 3, 0, 64), [1, 64, 64, 64]), [1, 64, 64, 64], "f16");
return {out0: v5, out1: v6};
}, {v0: k.tensor([1, 64, 64, 64], "f16"), v1: k.tensor([1, 64, 64, 64], "f16"), v2: k.tensor([1, 64, 64, 64], "f16")});
