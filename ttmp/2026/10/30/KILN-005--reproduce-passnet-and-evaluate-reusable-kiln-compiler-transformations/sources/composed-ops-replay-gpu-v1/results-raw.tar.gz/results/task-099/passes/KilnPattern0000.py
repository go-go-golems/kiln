from operator import iadd as kiln_iadd
import torch

def pattern(in_7, in_5, in_6, in_1, in_2, in_4, in_3, in_0):
    tmp_0 = in_0
    tmp_1 = in_1
    tmp_2 = in_2
    tmp_3 = in_3
    tmp_4 = in_4
    tmp_5 = in_5
    tmp_6 = torch.conv2d(in_7, tmp_5, None, (1, 1), (4, 4), (4, 4), 64)
    tmp_7 = torch.cat([in_6, tmp_6], 1)
    tmp_8 = torch.nn.functional.batch_norm(tmp_7, tmp_1, tmp_2, tmp_4, tmp_3, False, 0.1, 0.001)
    tmp_9 = torch.prelu(tmp_8, tmp_0)
    tmp_10 = torch.nn.functional.adaptive_avg_pool2d(tmp_9, 1)
    tmp_11 = tmp_10.view(32, 128)
    return (tmp_9, tmp_11)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_7, in_5, in_6, in_1, in_2, in_4, in_3, in_0):
 return (in_7, in_5, in_6, in_1, in_2, in_4, in_3, in_0, 0)
def replacement_func():
 return kiln_generated
