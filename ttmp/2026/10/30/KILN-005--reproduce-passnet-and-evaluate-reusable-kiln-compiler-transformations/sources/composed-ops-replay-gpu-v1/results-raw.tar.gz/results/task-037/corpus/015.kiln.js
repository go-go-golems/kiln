project("passnet").program(({v0}) => {
const v1 = N.expect(N.cast(N.silu(N.cast(v0, "f32")), "f32"), [32, 2304, 8, 8], "f32");
const v2 = N.expect(N.adaptiveAvgPool2d(v1, [1, 1]), [32, 2304, 1, 1], "f32");
const v3 = N.expect(N.reshape(v2, [32, 2304]), [32, 2304], "f32");
const v4 = N.expect(v3, [32, 2304], "f32");
return {out0: v4, __mut0: v1};
}, {v0: k.tensor([32, 2304, 8, 8], "f32")});
