const passnetProject = project("passnet").program(({v0, v1, v2, v3, v4, v5, v6, v7}) => {
const v8 = N.expect(N.conv2d(v0, v1, null, {"stride": [1, 1], "padding": [4, 4], "dilation": [4, 4], "groups": 64}), [128, 64, 32, 32], "f16");
const v9 = N.expect(N.concat([v2, v8], 1), [128, 128, 32, 32], "f16");
const v10 = N.expect(N.cast(N.add(N.mul(N.div(N.sub(N.cast(v9, "f32"), N.reshape(N.cast(v3, "f32"), [1, 128, 1, 1])), N.sqrt(N.add(N.reshape(N.cast(v4, "f32"), [1, 128, 1, 1]), 0.001))), N.reshape(N.cast(v5, "f32"), [1, 128, 1, 1])), N.reshape(N.cast(v6, "f32"), [1, 128, 1, 1])), "f16"), [128, 128, 32, 32], "f16");
const v11 = N.expect(N.select(N.gt(v10, 0), v10, N.mul(N.reshape(v7, [1, 128, 1, 1]), v10)), [128, 128, 32, 32], "f16");
const v12 = N.expect(N.adaptiveAvgPool2d(v11, [1, 1]), [128, 128, 1, 1], "f16");
const v13 = N.expect(N.reshape(v12, [128, 128]), [128, 128], "f16");
return {out0: v11, out1: v13};
}, {v0: k.tensor([128, 64, 32, 32], "f16"), v1: k.tensor([64, 1, 3, 3], "f16"), v2: k.tensor([128, 64, 32, 32], "f16"), v3: k.tensor([128], "f16"), v4: k.tensor([128], "f16"), v5: k.tensor([128], "f16"), v6: k.tensor([128], "f16"), v7: k.tensor([128], "f16")});
const passnetReferenceInputs = passnetProject.inputsFor(passnetProject.graph(), {names: ["v4"]});
for (let i=0; i<passnetReferenceInputs.v4.data.length; i++) passnetReferenceInputs.v4.data[i] = Math.abs(passnetReferenceInputs.v4.data[i]) + 0.1;
passnetProject.data(passnetReferenceInputs);
