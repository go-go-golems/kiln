project("passnet").program(({v0}) => {
const v1 = N.expect(N.relu(v0), [24, 512, 64, 64], "f32");
const v2 = N.expect(v1, [24, 512, 64, 64], "f32");
return {out0: v2, __mut0: v1};
}, {v0: k.tensor([24, 512, 64, 64], "f32")});
