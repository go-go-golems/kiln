project("passnet").program(({v0}) => {
const v1 = N.expect(N.concat([v0], 1), [128, 768], "bf16");
const v2 = N.expect(N.div(v1, N.max(N.cast(N.sqrt(N.sum(N.mul(N.cast(v1, "f32"), N.cast(v1, "f32")), 1, true)), "bf16"), 1e-12)), [128, 768], "bf16");
return {out0: v2};
}, {v0: k.tensor([128, 768], "bf16")});
