project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.relu(v0), [256, 133, 8, 6], "bf16");
const v3 = N.expect(N.reshape(v2, [256, 133, 48]), [256, 133, 48], "bf16");
const v4 = N.expect(N.cast(N.sqrt(N.sum(N.mul(N.cast(v3, "f32"), N.cast(v3, "f32")), 2, true)), "bf16"), [256, 133, 1], "bf16");
const v5 = N.expect(N.mul(v4, 0.14433756729740643), [256, 133, 1], "bf16");
const v6 = N.expect(N.cast(N.select(N.lt(N.cast(v5, "f32"), N.cast(N.cast(N.const(1e-05, []), "bf16"), "f32")), N.cast(N.cast(N.const(1e-05, []), "bf16"), "f32"), N.cast(v5, "f32")), "bf16"), [256, 133, 1], "bf16");
const v7 = N.expect(N.div(v3, v6), [256, 133, 48], "bf16");
const v8 = N.expect(N.mul(v7, v1), [256, 133, 48], "bf16");
return {out0: v8, __mut0: v2};
}, {v0: k.tensor([256, 133, 8, 6], "bf16"), v1: k.tensor([1], "bf16")});
