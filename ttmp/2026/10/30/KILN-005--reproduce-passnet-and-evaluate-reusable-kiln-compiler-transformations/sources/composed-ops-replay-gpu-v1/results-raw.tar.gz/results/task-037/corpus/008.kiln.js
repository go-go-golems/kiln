project("passnet").program(({v0}) => {
const v1 = N.expect(N.cast(N.silu(N.cast(v0, "f32")), "bf16"), [128, 1408, 7, 7], "bf16");
const v2 = N.expect(N.adaptiveAvgPool2d(v1, [1, 1]), [128, 1408, 1, 1], "bf16");
const v3 = N.expect(N.reshape(v2, [128, 1408]), [128, 1408], "bf16");
const v4 = N.expect(v3, [128, 1408], "bf16");
return {out0: v4, __mut0: v1};
}, {v0: k.tensor([128, 1408, 7, 7], "bf16")});
