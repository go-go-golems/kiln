project("passnet").program(({v0}) => {
const v1 = N.expect(N.concat([v0], 1), [64, 768], "f32");
const v2 = N.expect(N.div(v1, N.max(N.cast(N.sqrt(N.sum(N.mul(N.cast(v1, "f32"), N.cast(v1, "f32")), 1, true)), "f32"), 1e-12)), [64, 768], "f32");
return {out0: v2};
}, {v0: k.tensor([64, 768], "f32")});
