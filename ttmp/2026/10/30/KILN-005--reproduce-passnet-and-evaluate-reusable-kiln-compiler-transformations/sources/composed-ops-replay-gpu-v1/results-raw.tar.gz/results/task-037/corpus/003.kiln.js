project("passnet").program(({v0}) => {
const v1 = N.expect(N.cast(N.silu(N.cast(v0, "f32")), "f16"), [128, 1792, 8, 8], "f16");
const v2 = N.expect(N.adaptiveAvgPool2d(v1, [1, 1]), [128, 1792, 1, 1], "f16");
const v3 = N.expect(N.reshape(v2, [128, 1792]), [128, 1792], "f16");
const v4 = N.expect(v3, [128, 1792], "f16");
return {out0: v4, __mut0: v1};
}, {v0: k.tensor([128, 1792, 8, 8], "f16")});
