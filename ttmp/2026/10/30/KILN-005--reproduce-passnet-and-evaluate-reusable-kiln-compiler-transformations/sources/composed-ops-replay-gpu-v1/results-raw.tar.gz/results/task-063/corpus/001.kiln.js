project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.cast(N.sigmoid(N.cast(v0, "f32")), "f16"), [1, 512], "f16");
const v3 = N.expect(N.reshape(v2, [1, 512, 1, 1]), [1, 512, 1, 1], "f16");
const v4 = N.expect(N.mul(v1, v3), [1, 512, 64, 64], "f16");
const v5 = N.expect(N.add(v1, v4), [1, 512, 64, 64], "f16");
const v6 = N.expect(N.relu(v5), [1, 512, 64, 64], "f16");
const v7 = N.expect(v6, [1, 512, 64, 64], "f16");
return {out0: v7};
}, {v0: k.tensor([1, 512], "f16"), v1: k.tensor([1, 512, 64, 64], "f16")});
