project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.relu(v0), [512, 133, 16, 12], "f32");
const v3 = N.expect(N.reshape(v2, [512, 133, 192]), [512, 133, 192], "f32");
const v4 = N.expect(N.cast(N.sqrt(N.sum(N.mul(N.cast(v3, "f32"), N.cast(v3, "f32")), 2, true)), "f32"), [512, 133, 1], "f32");
const v5 = N.expect(N.mul(v4, 0.07216878364870322), [512, 133, 1], "f32");
const v6 = N.expect(N.cast(N.select(N.lt(N.cast(v5, "f32"), N.cast(N.cast(N.const(1e-05, []), "f32"), "f32")), N.cast(N.cast(N.const(1e-05, []), "f32"), "f32"), N.cast(v5, "f32")), "f32"), [512, 133, 1], "f32");
const v7 = N.expect(N.div(v3, v6), [512, 133, 192], "f32");
const v8 = N.expect(N.mul(v7, v1), [512, 133, 192], "f32");
return {out0: v8, __mut0: v2};
}, {v0: k.tensor([512, 133, 16, 12], "f32"), v1: k.tensor([1], "f32")});
