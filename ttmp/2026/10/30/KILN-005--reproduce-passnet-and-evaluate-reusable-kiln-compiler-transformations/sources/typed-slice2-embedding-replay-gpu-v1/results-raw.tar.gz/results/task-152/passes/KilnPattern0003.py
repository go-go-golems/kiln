from operator import iadd as kiln_iadd
import torch

def pattern(in_0, in_3, in_6, in_2, in_7, in_1, in_5, in_4):
    tmp_7 = torch.nn.functional.embedding(in_0, in_3, 0, None, 2.0, False, False)
    tmp_8 = torch.nn.functional.embedding(in_6, in_2, None, None, 2.0, False, False)
    tmp_9 = tmp_7 + tmp_8
    tmp_10 = torch.nn.functional.embedding(in_7, in_1, None, None, 2.0, False, False)
    tmp_9 = kiln_iadd(tmp_9, tmp_10)
    tmp_11 = tmp_9
    tmp_12 = torch.nn.functional.dropout(tmp_11, 0.1, False, False)
    tmp_13 = torch.nn.functional.layer_norm(tmp_12, (64,), in_5, in_4, 1e-12)
    return (tmp_12, tmp_13)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_0, in_3, in_6, in_2, in_7, in_1, in_5, in_4):
 return (in_0, in_3, in_6, in_2, in_7, in_1, in_5, in_4, 3)
def replacement_func():
 return kiln_generated
