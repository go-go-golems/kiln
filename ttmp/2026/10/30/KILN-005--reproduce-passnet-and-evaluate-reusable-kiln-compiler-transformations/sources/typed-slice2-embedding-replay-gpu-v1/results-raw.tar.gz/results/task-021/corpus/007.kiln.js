project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.embedding(v0, v1), [1, 64, 128], "f16");
const v3 = N.expect(N.reshape(N.slice(v2, 1, 1, 64), [1, 63, 128]), [1, 63, 128], "f16");
const v4 = N.expect(N.pad(v3, [0, 0, 0, 1, 0, 0], "constant", 0.0), [1, 64, 128], "f16");
const v5 = N.expect(N.reshape(N.slice(v2, 1, 0, 63), [1, 63, 128]), [1, 63, 128], "f16");
const v6 = N.expect(N.pad(v5, [0, 0, 1, 0, 0, 0], "constant", 0.0), [1, 64, 128], "f16");
const v7 = N.expect(N.concat([v4, v2, v6], 2), [1, 64, 384], "f16");
return {out0: v7};
}, {v0: k.tensor([1, 64], "i64"), v1: k.tensor([30522, 128], "f16")});
