project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.embedding(v0, v1), [128, 64, 1536], "bf16");
const v4 = N.expect(N.cast(v2, "i64"), [128, 64], "i64");
return {out0: v3, out1: v4};
}, {v0: k.tensor([128, 64], "i64"), v1: k.tensor([151936, 1536], "bf16"), v2: k.tensor([128, 64], "i64")});
