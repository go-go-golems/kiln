project("passnet").program(({v0, v1, v2, v3, v4, v5, v6, v7}) => {
const v8 = N.expect(N.embedding(v0, v1), [1, 11, 768], "f16");
const v9 = N.expect(N.embedding(v2, v3), [1, 11, 768], "f16");
const v10 = N.expect(N.add(v8, v9), [1, 11, 768], "f16");
const v11 = N.expect(N.embedding(v4, v5), [1, 11, 768], "f16");
const v12 = N.expect(N.add(v10, v11), [1, 11, 768], "f16");
const v13 = N.expect(v12, [1, 11, 768], "f16");
const v14 = N.expect(N.cast(N.reshape(N.layer_norm(N.reshape(N.cast(v13, "f32"), [11, 768]), N.reshape(N.cast(v6, "f32"), [768]), N.reshape(N.cast(v7, "f32"), [768]), {"eps": 1e-12}), [1, 11, 768]), "f16"), [1, 11, 768], "f16");
return {out0: v14};
}, {v0: k.tensor([1, 11], "i64"), v1: k.tensor([50358, 768], "f16"), v2: k.tensor([1, 11], "i64"), v3: k.tensor([2, 768], "f16"), v4: k.tensor([1, 11], "i64"), v5: k.tensor([4096, 768], "f16"), v6: k.tensor([768], "f16"), v7: k.tensor([768], "f16")});
