from operator import iadd as kiln_iadd
import torch

def pattern(in_1, in_2, in_0):
    tmp_0 = in_0
    tmp_1 = in_1
    tmp_2 = in_2
    tmp_3 = torch.nn.functional.embedding(tmp_1, tmp_2, None, None, 2.0, False, False)
    tmp_4 = tmp_0.long()
    return (tmp_3, tmp_4)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_1, in_2, in_0):
 return (in_1, in_2, in_0, 0)
def replacement_func():
 return kiln_generated
