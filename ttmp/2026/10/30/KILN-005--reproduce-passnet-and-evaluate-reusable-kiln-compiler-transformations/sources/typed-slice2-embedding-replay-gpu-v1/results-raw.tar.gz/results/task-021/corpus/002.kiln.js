project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.embedding(v0, v1), [1, 11, 128], "bf16");
const v3 = N.expect(N.reshape(N.slice(v2, 1, 1, 11), [1, 10, 128]), [1, 10, 128], "bf16");
const v4 = N.expect(N.pad(v3, [0, 0, 0, 1, 0, 0], "constant", 0.0), [1, 11, 128], "bf16");
const v5 = N.expect(N.reshape(N.slice(v2, 1, 0, 10), [1, 10, 128]), [1, 10, 128], "bf16");
const v6 = N.expect(N.pad(v5, [0, 0, 1, 0, 0, 0], "constant", 0.0), [1, 11, 128], "bf16");
const v7 = N.expect(N.concat([v4, v2, v6], 2), [1, 11, 384], "bf16");
return {out0: v7};
}, {v0: k.tensor([1, 11], "i64"), v1: k.tensor([30522, 128], "bf16")});
