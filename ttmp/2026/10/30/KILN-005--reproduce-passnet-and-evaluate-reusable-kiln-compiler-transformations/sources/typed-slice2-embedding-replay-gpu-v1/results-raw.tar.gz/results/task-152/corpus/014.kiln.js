project("passnet").program(({v0, v1, v2, v3, v4, v5, v6, v7}) => {
const v8 = N.expect(N.embedding(v0, v1), [32, 64, 64], "f32");
const v9 = N.expect(N.embedding(v2, v3), [32, 64, 64], "f32");
const v10 = N.expect(N.add(v8, v9), [32, 64, 64], "f32");
const v11 = N.expect(N.embedding(v4, v5), [1, 64, 64], "f32");
const v12 = N.expect(N.add(v10, v11), [32, 64, 64], "f32");
const v13 = N.expect(v12, [32, 64, 64], "f32");
const v14 = N.expect(N.cast(N.reshape(N.layer_norm(N.reshape(N.cast(v13, "f32"), [2048, 64]), N.reshape(N.cast(v6, "f32"), [64]), N.reshape(N.cast(v7, "f32"), [64]), {"eps": 1e-12}), [32, 64, 64]), "f32"), [32, 64, 64], "f32");
return {out0: v13, out1: v14};
}, {v0: k.tensor([32, 64], "i64"), v1: k.tensor([1124, 64], "f32"), v2: k.tensor([32, 64], "i64"), v3: k.tensor([16, 64], "f32"), v4: k.tensor([1, 64], "i64"), v5: k.tensor([512, 64], "f32"), v6: k.tensor([64], "f32"), v7: k.tensor([64], "f32")});
