project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.conv2d(v0, v1, null, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [1, 128, 32, 32], "f32");
const v3 = N.expect(N.reshape(N.transpose(N.transpose(N.unfold(N.unfold(v2, 2, 2, 2), 3, 2, 2), 2, 4), 3, 5), [1, 512, 256]), [1, 512, 256], "f32");
const v4 = N.expect(N.reshape(v3, [1, 128, 4, 256]), [1, 128, 4, 256], "f32");
return {out0: v4};
}, {v0: k.tensor([1, 256, 32, 32], "f32"), v1: k.tensor([128, 256, 1, 1], "f32")});
