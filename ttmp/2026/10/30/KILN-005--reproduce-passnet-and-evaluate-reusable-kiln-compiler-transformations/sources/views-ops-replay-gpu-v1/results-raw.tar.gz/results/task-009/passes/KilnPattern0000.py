from operator import iadd as kiln_iadd
import torch

def pattern(in_2, in_3, in_0, in_1):
    tmp_0 = torch.cat((in_2, in_3), 1)
    tmp_1 = torch.nn.functional.interpolate(in_0, size=(40, 40), mode='nearest')
    tmp_2 = torch.nn.functional.interpolate(in_1, size=(40, 40), mode='nearest')
    tmp_3 = torch.stack([tmp_1, tmp_2, tmp_0])
    return tmp_3
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_2, in_3, in_0, in_1):
 return (in_2, in_3, in_0, in_1, 0)
def replacement_func():
 return kiln_generated
