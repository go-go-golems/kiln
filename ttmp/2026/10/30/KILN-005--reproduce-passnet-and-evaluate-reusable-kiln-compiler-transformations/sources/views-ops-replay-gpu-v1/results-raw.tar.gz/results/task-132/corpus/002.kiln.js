project("passnet").program(({v0}) => {
const v1 = N.expect(N.reshape(v0, [1, 384, 11]), [1, 384, 11], "f16");
const v2 = N.expect(N.reshape(v1, [1, 384, 11, 1]), [1, 384, 11, 1], "f16");
const v3 = N.expect(N.reshape(N.transpose(N.transpose(N.unfold(N.unfold(N.pad(v2, [0, 0, 4, 4]), 2, 9, 1), 3, 1, 1), 2, 4), 3, 5), [1, 3456, 11]), [1, 3456, 11], "f16");
const v4 = N.expect(N.transpose(v3, 1, 2), [1, 11, 3456], "f16");
const v5 = N.expect(N.reshape(v4, [1, 11, 384, 9]), [1, 11, 384, 9], "f16");
const v6 = N.expect(N.reshape(v5, [66, 64, 9]), [66, 64, 9], "f16");
return {out0: v6};
}, {v0: k.tensor([1, 384, 11], "f16")});
