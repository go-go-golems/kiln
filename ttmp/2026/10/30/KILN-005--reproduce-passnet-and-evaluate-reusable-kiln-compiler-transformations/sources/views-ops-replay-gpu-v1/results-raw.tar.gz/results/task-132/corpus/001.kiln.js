project("passnet").program(({v0}) => {
const v1 = N.expect(N.reshape(v0, [1, 16, 45]), [1, 16, 45], "bf16");
const v2 = N.expect(N.reshape(v1, [1, 16, 45, 1]), [1, 16, 45, 1], "bf16");
const v3 = N.expect(N.reshape(N.transpose(N.transpose(N.unfold(N.unfold(N.pad(v2, [0, 0, 4, 4]), 2, 9, 1), 3, 1, 1), 2, 4), 3, 5), [1, 144, 45]), [1, 144, 45], "bf16");
const v4 = N.expect(N.transpose(v3, 1, 2), [1, 45, 144], "bf16");
const v5 = N.expect(N.reshape(v4, [1, 45, 16, 9]), [1, 45, 16, 9], "bf16");
const v6 = N.expect(N.reshape(v5, [90, 8, 9]), [90, 8, 9], "bf16");
return {out0: v6};
}, {v0: k.tensor([1, 16, 45], "bf16")});
