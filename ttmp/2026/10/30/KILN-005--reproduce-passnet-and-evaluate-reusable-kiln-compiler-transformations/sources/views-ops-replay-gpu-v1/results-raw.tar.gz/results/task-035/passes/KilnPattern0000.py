from operator import iadd as kiln_iadd
import torch

def pattern(in_1, in_2, in_0):
    tmp_0 = torch.nn.functional.unfold(in_1, kernel_size=(384, 384), stride=(192, 192))
    tmp_1 = tmp_0.permute(2, 0, 1)
    tmp_2 = tmp_1.reshape(-1, 3, 384, 384)
    tmp_3 = torch.nn.functional.unfold(in_2, kernel_size=(384, 384), stride=(288, 288))
    tmp_4 = tmp_3.permute(2, 0, 1)
    tmp_5 = tmp_4.reshape(-1, 3, 384, 384)
    tmp_6 = torch.cat([tmp_5, tmp_2, in_0], dim=0)
    tmp_7 = tmp_6.to(dtype=torch.float16)
    return tmp_7
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_1, in_2, in_0):
 return (in_1, in_2, in_0, 0)
def replacement_func():
 return kiln_generated
