project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.reshape(N.transpose(N.transpose(N.unfold(N.unfold(v0, 2, 384, 192), 3, 384, 192), 2, 4), 3, 5), [1, 442368, 9]), [1, 442368, 9], "bf16");
const v4 = N.expect(N.transpose(N.transpose(v3, 0, 2), 1, 2), [9, 1, 442368], "bf16");
const v5 = N.expect(N.reshape(v4, [9, 3, 384, 384]), [9, 3, 384, 384], "bf16");
const v6 = N.expect(N.reshape(N.transpose(N.transpose(N.unfold(N.unfold(v1, 2, 384, 288), 3, 384, 288), 2, 4), 3, 5), [1, 442368, 25]), [1, 442368, 25], "bf16");
const v7 = N.expect(N.transpose(N.transpose(v6, 0, 2), 1, 2), [25, 1, 442368], "bf16");
const v8 = N.expect(N.reshape(v7, [25, 3, 384, 384]), [25, 3, 384, 384], "bf16");
const v9 = N.expect(N.concat([v8, v5, v2], 0), [35, 3, 384, 384], "bf16");
const v10 = N.expect(N.cast(v9, "f16"), [35, 3, 384, 384], "f16");
return {out0: v10};
}, {v0: k.tensor([1, 3, 768, 768], "bf16"), v1: k.tensor([1, 3, 1536, 1536], "bf16"), v2: k.tensor([1, 3, 384, 384], "bf16")});
