project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.expect(N.concat([v0, v1], 1), [16, 512, 40, 40], "bf16");
const v5 = N.expect(N.resizeNearest(v2, [40, 40]), [16, 512, 40, 40], "bf16");
const v6 = N.expect(N.resizeNearest(v3, [40, 40]), [16, 512, 40, 40], "bf16");
const v7 = N.expect(N.concat([N.reshape(v5, [1, 16, 512, 40, 40]), N.reshape(v6, [1, 16, 512, 40, 40]), N.reshape(v4, [1, 16, 512, 40, 40])], 0), [3, 16, 512, 40, 40], "bf16");
return {out0: v7};
}, {v0: k.tensor([16, 256, 40, 40], "bf16"), v1: k.tensor([16, 256, 40, 40], "bf16"), v2: k.tensor([16, 512, 40, 40], "bf16"), v3: k.tensor([16, 512, 20, 20], "bf16")});
