project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.expect(N.concat([v0, v1], 1), [4, 512, 40, 40], "f16");
const v5 = N.expect(N.resizeNearest(v2, [40, 40]), [4, 512, 40, 40], "f16");
const v6 = N.expect(N.resizeNearest(v3, [40, 40]), [4, 512, 40, 40], "f16");
const v7 = N.expect(N.concat([N.reshape(v5, [1, 4, 512, 40, 40]), N.reshape(v6, [1, 4, 512, 40, 40]), N.reshape(v4, [1, 4, 512, 40, 40])], 0), [3, 4, 512, 40, 40], "f16");
return {out0: v7};
}, {v0: k.tensor([4, 256, 40, 40], "f16"), v1: k.tensor([4, 256, 40, 40], "f16"), v2: k.tensor([4, 512, 40, 40], "f16"), v3: k.tensor([4, 512, 20, 20], "f16")});
