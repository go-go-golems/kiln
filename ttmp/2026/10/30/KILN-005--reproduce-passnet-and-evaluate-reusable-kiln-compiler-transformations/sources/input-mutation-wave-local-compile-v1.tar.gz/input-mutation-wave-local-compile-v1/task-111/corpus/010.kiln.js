project("passnet").program(({v0, v1, v2}) => {
const v3 = N.conv2d(v2, v0, null, {"stride": [1, 1], "padding": [32, 0], "dilation": [1, 1], "groups": 12});
const v4 = N.add(v1, v3);
const v5 = N.transpose(v4, 1, 2);
const v6 = N.reshape(v5, [1, 16, 12, 64]);
const v7 = N.reshape(v6, [1, 16, 768]);
return {out0: v7, __mut1: v4};
}, {v0: k.tensor([12, 1, 65, 1], "f16"), v1: k.tensor([1, 12, 16, 64], "f16"), v2: k.tensor([1, 12, 16, 64], "f16")});
