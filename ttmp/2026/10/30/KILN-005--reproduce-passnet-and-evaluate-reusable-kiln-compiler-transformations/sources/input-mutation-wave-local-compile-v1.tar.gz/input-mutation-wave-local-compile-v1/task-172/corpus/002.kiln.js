project("passnet").program(({v0, v1}) => {
const v2 = N.add(v1, v0);
const v3 = N.cast(v2, "f32");
const v4 = N.cast(N.softmax(N.cast(v3, "f32"), 3), "f32");
const v5 = N.cast(v4, "f16");
const v6 = v5;
return {out0: v6, __mut1: v2};
}, {v0: k.tensor([1, 16, 8, 8], "f16"), v1: k.tensor([1, 16, 8, 8], "f16")});
