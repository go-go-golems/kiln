project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.cast(N.linear(N.cast(v3, "f32"), N.cast(v1, "f32"), N.cast(v0, "f32")), "bf16");
const v5 = N.add(v2, v4);
const v6 = N.relu(v5);
return {out0: v6};
}, {v0: k.tensor([128], "bf16"), v1: k.tensor([128, 128], "bf16"), v2: k.tensor([1000, 128], "bf16"), v3: k.tensor([1000, 128], "bf16")});
