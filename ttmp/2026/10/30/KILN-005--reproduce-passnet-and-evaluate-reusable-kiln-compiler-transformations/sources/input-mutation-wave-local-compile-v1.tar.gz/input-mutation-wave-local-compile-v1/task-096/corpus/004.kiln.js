project("passnet").program(({v0, v1}) => {
const v2 = N.cast(N.silu(N.cast(v1, "f32")), "f32");
const v3 = N.add(v2, v0);
return {out0: v3, __mut1: v2};
}, {v0: k.tensor([4, 128, 16, 16], "f32"), v1: k.tensor([4, 128, 16, 16], "f32")});
