const passnetProject = project("passnet").program(({v0, v1, v2, v3, v4, v5, v6}) => {
const v7 = N.conv2d(v5, v0, null, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v8 = N.cast(N.add(N.mul(N.div(N.sub(N.cast(v7, "f32"), N.reshape(N.cast(v1, "f32"), [1, 128, 1, 1])), N.sqrt(N.add(N.reshape(N.cast(v2, "f32"), [1, 128, 1, 1]), 1e-05))), N.reshape(N.cast(v4, "f32"), [1, 128, 1, 1])), N.reshape(N.cast(v3, "f32"), [1, 128, 1, 1])), "f16");
const v9 = N.add(v6, v8);
return {__mut6: v9};
}, {v0: k.tensor([128, 64, 1, 1], "f16"), v1: k.tensor([128], "f16"), v2: k.tensor([128], "f16"), v3: k.tensor([128], "f16"), v4: k.tensor([128], "f16"), v5: k.tensor([128, 64, 32, 32], "f16"), v6: k.tensor([128, 128, 32, 32], "f16")});
const passnetReferenceInputs = passnetProject.inputsFor(passnetProject.graph(), {names: ["v2"]});
for (let i=0; i<passnetReferenceInputs.v2.data.length; i++) passnetReferenceInputs.v2.data[i] = Math.abs(passnetReferenceInputs.v2.data[i]) + 0.1;
passnetProject.data(passnetReferenceInputs);
