project("passnet").program(({v0, v1}) => {
const v2 = N.add(v1, v0);
const v3 = N.transpose(v2, 1, 2);
return {out0: v3, __mut1: v2};
}, {v0: k.tensor([128, 1], "f16"), v1: k.tensor([1, 128, 19], "f16")});
