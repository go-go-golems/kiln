const passnetProject = project("passnet").program(({v0, v1, v2, v3, v4, v5, v6}) => {
const v7 = N.conv2d(v6, v4, null, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v8 = N.cast(N.add(N.mul(N.div(N.sub(N.cast(v7, "f32"), N.reshape(N.cast(v0, "f32"), [1, 1024, 1, 1])), N.sqrt(N.add(N.reshape(N.cast(v1, "f32"), [1, 1024, 1, 1]), 1e-05))), N.reshape(N.cast(v3, "f32"), [1, 1024, 1, 1])), N.reshape(N.cast(v2, "f32"), [1, 1024, 1, 1])), "f32");
const v9 = N.add(v8, v5);
return {out0: v9};
}, {v0: k.tensor([1024], "f32"), v1: k.tensor([1024], "f32"), v2: k.tensor([1024], "f32"), v3: k.tensor([1024], "f32"), v4: k.tensor([1024, 256, 1, 1], "f32"), v5: k.tensor([32, 1024, 16, 16], "f32"), v6: k.tensor([32, 256, 16, 16], "f32")});
const passnetReferenceInputs = passnetProject.inputsFor(passnetProject.graph(), {names: ["v1"]});
for (let i=0; i<passnetReferenceInputs.v1.data.length; i++) passnetReferenceInputs.v1.data[i] = Math.abs(passnetReferenceInputs.v1.data[i]) + 0.1;
passnetProject.data(passnetReferenceInputs);
