project("passnet").program(({v0, v1}) => {
const v2 = N.cast(N.silu(N.cast(v1, "f32")), "f16");
const v3 = N.add(v2, v0);
return {out0: v3, __mut1: v2};
}, {v0: k.tensor([16, 128, 32, 24], "f16"), v1: k.tensor([16, 128, 32, 24], "f16")});
