project("passnet").program(({v0, v1, v2}) => {
const v3 = N.conv2d(v2, v0, null, {"stride": [1, 1], "padding": [32, 0], "dilation": [1, 1], "groups": 4});
const v4 = N.add(v1, v3);
const v5 = N.transpose(v4, 1, 2);
const v6 = N.reshape(v5, [128, 64, 4, 8]);
const v7 = N.reshape(v6, [128, 64, 32]);
return {out0: v7, __mut1: v4};
}, {v0: k.tensor([4, 1, 65, 1], "f32"), v1: k.tensor([128, 4, 64, 8], "f32"), v2: k.tensor([128, 4, 64, 8], "f32")});
