from operator import iadd as kiln_iadd
import torch

def pattern(in_2, in_5, in_3, in_4, in_1, in_0):
    tmp_2 = torch.cat((in_2, in_5, in_3), dim=2)
    in_2 = in_5 = in_3 = None
    tmp_3 = torch.nn.functional.layer_norm(in_4, (32,), in_1, in_0, 1e-12)
    in_4 = in_1 = in_0 = None
    return (tmp_3, tmp_2)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_2, in_5, in_3, in_4, in_1, in_0):
 return (in_2, in_5, in_3, in_4, in_1, in_0, 2)
def replacement_func():
 return kiln_generated
