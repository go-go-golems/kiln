from operator import iadd as kiln_iadd
import torch

def pattern(in_0, in_2, in_1):
    tmp_0 = in_0 / 8.0
    in_0 = None
    tmp_0 = kiln_iadd(tmp_0, in_2)
    tmp_1 = tmp_0
    tmp_0 = in_2 = None
    tmp_2 = tmp_1 + in_1
    tmp_1 = in_1 = None
    return tmp_2
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_0, in_2, in_1):
 return (in_0, in_2, in_1, 0)
def replacement_func():
 return kiln_generated
