project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v5 = N.reshape(v4, [64, 256, 4096]);
const v6 = N.cast(N.mul(N.sum(N.cast(v3, "f32"), 1, true), 0.000244140625), "f32");
return {out0: v6, out1: v5};
}, {v0: k.tensor([64, 512, 64, 64], "f32"), v1: k.tensor([256, 512, 1, 1], "f32"), v2: k.tensor([256], "f32"), v3: k.tensor([64, 4096, 256], "f32")});
