project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v5 = v4;
const v6 = N.add(v5, v3);
return {out0: v6};
}, {v0: k.tensor([1, 256, 4, 256], "f32"), v1: k.tensor([128, 256, 1, 1], "f32"), v2: k.tensor([128], "f32"), v3: k.tensor([1, 128, 4, 256], "f32")});
