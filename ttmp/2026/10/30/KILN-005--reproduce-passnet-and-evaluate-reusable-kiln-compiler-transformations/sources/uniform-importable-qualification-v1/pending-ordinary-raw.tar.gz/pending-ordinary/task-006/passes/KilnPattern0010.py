from operator import iadd as kiln_iadd
import torch

def pattern(in_1, in_0):
    tmp_0 = in_0
    tmp_1 = torch.conv2d(in_1, tmp_0, None, (1, 1), (0, 0), (1, 1), 1)
    tmp_0 = None
    tmp_2 = tmp_1[slice(None, None, None), slice(None, 256, None), slice(None, None, None), slice(None, None, None)]
    return (tmp_2, tmp_1)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_1, in_0):
 return (in_1, in_0, 10)
def replacement_func():
 return kiln_generated
