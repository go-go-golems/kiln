project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 4});
const v5 = N.cast(N.sigmoid(N.cast(v4, "f32")), "f32");
const v6 = N.reshape(v5, [1, 96, 1, 1]);
const v7 = N.mul(v3, v6);
const v8 = N.reshape(v7, [1, 96, 112, 112]);
return {out0: v8};
}, {v0: k.tensor([1, 32, 1, 1], "f32"), v1: k.tensor([96, 8, 1, 1], "f32"), v2: k.tensor([96], "f32"), v3: k.tensor([1, 96, 112, 112], "f32")});
