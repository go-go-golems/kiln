from operator import iadd as kiln_iadd
import torch

def pattern(in_3, in_1, in_0, in_2):
    conv2d = torch.conv2d(in_3, in_1, in_0, (1, 1), (0, 0), (1, 1), 1)
    in_3 = in_1 = in_0 = None
    tmp_3 = conv2d.view(2, 256, -1)
    conv2d = None
    tmp_4 = in_2.mean(dim=-2, keepdim=True)
    in_2 = None
    return (tmp_4, tmp_3)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_3, in_1, in_0, in_2):
 return (in_3, in_1, in_0, in_2, 0)
def replacement_func():
 return kiln_generated
