from operator import iadd as kiln_iadd
import torch

def pattern(in_1, in_0):
    tmp_0 = in_1.sum(dim=2, keepdim=True)
    tmp_1 = in_1 / tmp_0
    in_1 = tmp_0 = None
    tmp_2 = in_0.view(1, 2, 1, 8, 8)
    in_0 = None
    tmp_3 = tmp_2.expand(1, 2, 64, 8, 8)
    tmp_2 = None
    return (tmp_3, tmp_1)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_1, in_0):
 return (in_1, in_0, 0)
def replacement_func():
 return kiln_generated
