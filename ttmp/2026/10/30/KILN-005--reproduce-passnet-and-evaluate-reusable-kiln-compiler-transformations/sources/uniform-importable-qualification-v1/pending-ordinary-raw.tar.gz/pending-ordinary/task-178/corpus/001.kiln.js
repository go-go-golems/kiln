project("passnet").program(({v0, v1, v2, v3, v4}) => {
const v5 = N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v6 = N.reshape(v5, [32, 1, 400]);
const v7 = N.concat([v3, v4, v6], 2);
const v8 = N.cast(N.sigmoid(N.cast(v7, "f32")), "f16");
const v9 = N.sub(v8, 0.25);
const v10 = N.mul(v9, 3.141592653589793);
return {out0: v10};
}, {v0: k.tensor([32, 64, 20, 20], "f16"), v1: k.tensor([1, 64, 1, 1], "f16"), v2: k.tensor([1], "f16"), v3: k.tensor([32, 1, 6400], "f16"), v4: k.tensor([32, 1, 1600], "f16")});
