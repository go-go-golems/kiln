from operator import iadd as kiln_iadd
import torch

def pattern(in_3, in_2, in_1, in_0):
    tmp_2 = in_3 + in_2
    in_3 = in_2 = None
    tmp_3 = torch.nn.functional.layer_norm(tmp_2, (128,), in_1, in_0, 1e-05)
    tmp_2 = in_1 = in_0 = None
    tmp_4 = tmp_3.reshape(1, 2, 2, -1)
    tmp_3 = None
    tmp_5 = tmp_4.permute(0, 3, 1, 2)
    tmp_4 = None
    tmp_6 = tmp_5.contiguous()
    tmp_5 = None
    tmp_7 = tmp_6.permute(0, 2, 3, 1)
    tmp_6 = None
    tmp_8 = tmp_7.reshape(1, -1, 128)
    tmp_7 = None
    return tmp_8
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_3, in_2, in_1, in_0):
 return (in_3, in_2, in_1, in_0, 0)
def replacement_func():
 return kiln_generated
