project("passnet").program(({v0, v1}) => {
const v2 = N.conv2d(v0, v1, null, {"stride": [1, 1], "padding": [1, 1], "dilation": [1, 1], "groups": 768});
const v3 = N.cast(N.mul(N.sum(N.sum(N.cast(v2, "f32"), 2, true), 3, true), 0.0012755102040816326), "f32");
return {out0: v2, out1: v3};
}, {v0: k.tensor([1, 768, 28, 28], "f32"), v1: k.tensor([768, 1, 3, 3], "f32")});
