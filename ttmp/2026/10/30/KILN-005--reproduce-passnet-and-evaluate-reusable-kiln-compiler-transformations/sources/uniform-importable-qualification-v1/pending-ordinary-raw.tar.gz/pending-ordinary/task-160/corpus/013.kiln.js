project("passnet").program(({v0, v1}) => {
const v2 = N.cast(N.matmul(N.cast(v0, "f32"), N.cast(v1, "f32")), "f16");
const v3 = N.reshape(v2, [64, 608, 1, 1]);
return {out0: v3};
}, {v0: k.tensor([64, 1, 608, 48], "f16"), v1: k.tensor([64, 1, 48, 1], "f16")});
