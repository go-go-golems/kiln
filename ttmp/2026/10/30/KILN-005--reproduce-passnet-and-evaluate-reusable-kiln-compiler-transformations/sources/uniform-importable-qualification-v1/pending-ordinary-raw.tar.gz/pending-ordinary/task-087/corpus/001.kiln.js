project("passnet").program(({v0, v1}) => {
const v2 = N.cast(N.sum(N.cast(v0, "f32"), 2, true), "bf16");
const v3 = N.div(v0, v2);
const v4 = N.reshape(v1, [1, 2, 1, 8, 8]);
const v5 = N.expand(v4, [1, 2, 64, 8, 8]);
return {out0: v5, out1: v3};
}, {v0: k.tensor([1, 2, 8, 8], "bf16"), v1: k.tensor([1, 2, 8, 8], "bf16")});
