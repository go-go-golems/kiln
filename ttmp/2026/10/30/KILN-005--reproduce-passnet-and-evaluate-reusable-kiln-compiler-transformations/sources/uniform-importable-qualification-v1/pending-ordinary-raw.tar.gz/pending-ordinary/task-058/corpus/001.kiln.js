project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.add(v0, v1);
const v5 = N.div(v4, 2);
const v6 = N.cast(N.reshape(N.layer_norm(N.reshape(N.cast(v5, "f32"), [1, 768]), N.reshape(N.cast(v2, "f32"), [768]), N.reshape(N.cast(v3, "f32"), [768]), {"eps": 1e-12}), [1, 768]), "f16");
return {out0: v6};
}, {v0: k.tensor([1, 768], "f16"), v1: k.tensor([1, 768], "f16"), v2: k.tensor([768], "f16"), v3: k.tensor([768], "f16")});
