project("passnet").program(({v0, v1, v2}) => {
const v3 = N.div(v0, 8.0);
const v4 = N.add(v3, v1);
const v5 = N.add(v4, v2);
return {out0: v5};
}, {v0: k.tensor([2, 12, 7, 7], "f16"), v1: k.tensor([2, 12, 7, 7], "f16"), v2: k.tensor([2, 1, 1, 7], "f16")});
