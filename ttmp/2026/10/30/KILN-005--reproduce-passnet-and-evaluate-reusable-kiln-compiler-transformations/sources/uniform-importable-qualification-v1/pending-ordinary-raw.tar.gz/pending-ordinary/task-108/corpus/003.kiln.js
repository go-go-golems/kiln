project("passnet").program(({v0, v1}) => {
const v2 = N.conv2d(v0, v1, null, {"stride": [2, 2], "padding": [1, 1], "dilation": [1, 1], "groups": 256});
const v3 = N.cast(N.mul(N.sum(N.sum(N.cast(v2, "f32"), 2, true), 3, true), 0.00031887755102040814), "bf16");
return {out0: v2, out1: v3};
}, {v0: k.tensor([1, 256, 112, 112], "bf16"), v1: k.tensor([256, 1, 3, 3], "bf16")});
