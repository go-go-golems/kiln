project("passnet").program(({v0, v1, v2, v3, v4, v5}) => {
const v6 = N.concat([v0, v1, v2], 2);
const v7 = N.cast(N.reshape(N.layer_norm(N.reshape(N.cast(v3, "f32"), [236, 32]), N.reshape(N.cast(v4, "f32"), [32]), N.reshape(N.cast(v5, "f32"), [32]), {"eps": 1e-12}), [1, 236, 32]), "f16");
return {out0: v7, out1: v6};
}, {v0: k.tensor([4, 1, 1, 32], "f16"), v1: k.tensor([4, 1, 225, 32], "f16"), v2: k.tensor([4, 1, 10, 32], "f16"), v3: k.tensor([1, 236, 32], "f16"), v4: k.tensor([32], "f16"), v5: k.tensor([32], "f16")});
