project("passnet").program(({v0, v1, v2, v3, v4, v5}) => {
const v6 = N.concat([v0, v1, v2], 2);
const v7 = N.cast(N.reshape(N.layer_norm(N.reshape(N.cast(v3, "f32"), [2601, 768]), N.reshape(N.cast(v4, "f32"), [768]), N.reshape(N.cast(v5, "f32"), [768]), {"eps": 1e-12}), [1, 2601, 768]), "f16");
return {out0: v7, out1: v6};
}, {v0: k.tensor([11, 1, 1, 768], "f16"), v1: k.tensor([11, 1, 2500, 768], "f16"), v2: k.tensor([11, 1, 100, 768], "f16"), v3: k.tensor([1, 2601, 768], "f16"), v4: k.tensor([768], "f16"), v5: k.tensor([768], "f16")});
