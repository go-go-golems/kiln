from operator import iadd as kiln_iadd
import torch

def pattern(in_1, in_0):
    conv2d = torch.conv2d(in_1, in_0, None, (1, 1), (1, 1), (1, 1), 768)
    in_1 = in_0 = None
    tmp_2 = conv2d.mean((2, 3), keepdim=True)
    return (conv2d, tmp_2)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_1, in_0):
 return (in_1, in_0, 2)
def replacement_func():
 return kiln_generated
