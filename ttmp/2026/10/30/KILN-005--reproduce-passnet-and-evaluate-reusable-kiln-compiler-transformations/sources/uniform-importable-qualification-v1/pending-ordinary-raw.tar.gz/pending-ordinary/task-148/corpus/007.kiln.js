project("passnet").program(({v0, v1, v2}) => {
const v3 = N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v4 = N.reshape(v3, [4, 17, 3072]);
return {out0: v4};
}, {v0: k.tensor([4, 160, 64, 48], "f32"), v1: k.tensor([17, 160, 1, 1], "f32"), v2: k.tensor([17], "f32")});
