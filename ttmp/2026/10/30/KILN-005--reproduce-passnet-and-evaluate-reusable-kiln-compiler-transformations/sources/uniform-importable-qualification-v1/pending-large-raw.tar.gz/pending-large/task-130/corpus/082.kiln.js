project("passnet").program(({v0, v1, v2}) => {
const v3 = N.add(v0, v1);
const v4 = N.reshape(N.slice(v2, 1, 138, 152), [32, 14, 14, 14]);
const v5 = N.concat([v3, v4], 1);
return {out0: v5};
}, {v0: k.tensor([32, 138, 14, 14], "bf16"), v1: k.tensor([32, 138, 14, 14], "bf16"), v2: k.tensor([32, 152, 14, 14], "bf16")});
