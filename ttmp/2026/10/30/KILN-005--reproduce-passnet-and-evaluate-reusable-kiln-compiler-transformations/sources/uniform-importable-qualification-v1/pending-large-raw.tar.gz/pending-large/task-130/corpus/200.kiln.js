project("passnet").program(({v0, v1, v2}) => {
const v3 = N.add(v0, v1);
const v4 = N.reshape(N.slice(v2, 1, 288, 320), [32, 32, 24, 24]);
const v5 = N.concat([v3, v4], 1);
return {out0: v5};
}, {v0: k.tensor([32, 288, 24, 24], "f16"), v1: k.tensor([32, 288, 24, 24], "f16"), v2: k.tensor([32, 320, 24, 24], "f16")});
