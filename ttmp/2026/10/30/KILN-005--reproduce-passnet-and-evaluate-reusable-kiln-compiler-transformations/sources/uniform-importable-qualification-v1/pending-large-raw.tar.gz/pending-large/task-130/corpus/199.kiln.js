project("passnet").program(({v0, v1, v2}) => {
const v3 = N.add(v0, v1);
const v4 = N.reshape(N.slice(v2, 1, 84, 95), [128, 11, 16, 16]);
const v5 = N.concat([v3, v4], 1);
return {out0: v5};
}, {v0: k.tensor([128, 84, 16, 16], "bf16"), v1: k.tensor([128, 84, 16, 16], "bf16"), v2: k.tensor([128, 95, 16, 16], "bf16")});
