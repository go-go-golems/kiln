project("passnet").program(({v0, v1, v2}) => {
const v3 = N.add(v0, v1);
const v4 = N.reshape(N.slice(v2, 1, 75, 92), [32, 17, 48, 48]);
const v5 = N.concat([v3, v4], 1);
return {out0: v5};
}, {v0: k.tensor([32, 75, 48, 48], "f32"), v1: k.tensor([32, 75, 48, 48], "f32"), v2: k.tensor([32, 92, 48, 48], "f32")});
