from operator import iadd as kiln_iadd
import torch

def pattern(in_0, in_1, in_2):
    tmp_0 = in_0 + in_1
    in_0 = in_1 = None
    tmp_1 = in_2[slice(None, None, None), slice(65, None, None)]
    in_2 = None
    tmp_2 = torch.cat([tmp_0, tmp_1], dim=1)
    tmp_0 = tmp_1 = None
    return tmp_2
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_0, in_1, in_2):
 return (in_0, in_1, in_2, 4)
def replacement_func():
 return kiln_generated
