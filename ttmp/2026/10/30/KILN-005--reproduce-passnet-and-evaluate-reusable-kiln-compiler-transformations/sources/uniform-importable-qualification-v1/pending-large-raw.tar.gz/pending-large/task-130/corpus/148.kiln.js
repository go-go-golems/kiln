project("passnet").program(({v0, v1, v2}) => {
const v3 = N.add(v0, v1);
const v4 = N.reshape(N.slice(v2, 1, 192, 216), [1, 24, 16, 16]);
const v5 = N.concat([v3, v4], 1);
return {out0: v5};
}, {v0: k.tensor([1, 192, 16, 16], "f32"), v1: k.tensor([1, 192, 16, 16], "f32"), v2: k.tensor([1, 216, 16, 16], "f32")});
