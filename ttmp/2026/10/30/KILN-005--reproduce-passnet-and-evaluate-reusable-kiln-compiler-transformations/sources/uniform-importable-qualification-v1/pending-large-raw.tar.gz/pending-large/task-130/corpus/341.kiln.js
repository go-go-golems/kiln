project("passnet").program(({v0, v1, v2}) => {
const v3 = N.add(v0, v1);
const v4 = N.reshape(N.slice(v2, 1, 56, 80), [1, 24, 56, 56]);
const v5 = N.concat([v3, v4], 1);
return {out0: v5};
}, {v0: k.tensor([1, 56, 56, 56], "bf16"), v1: k.tensor([1, 56, 56, 56], "bf16"), v2: k.tensor([1, 80, 56, 56], "bf16")});
