project("passnet").program(({v0, v1, v2}) => {
const v3 = N.add(v0, v1);
const v4 = N.reshape(N.slice(v2, 1, 416, 448), [128, 32, 7, 7]);
const v5 = N.concat([v3, v4], 1);
return {out0: v5};
}, {v0: k.tensor([128, 416, 7, 7], "bf16"), v1: k.tensor([128, 416, 7, 7], "bf16"), v2: k.tensor([128, 448, 7, 7], "bf16")});
