project("passnet").program(({v0, v1, v2}) => {
const v3 = N.add(v0, v1);
const v4 = N.reshape(N.slice(v2, 1, 352, 386), [1, 34, 14, 14]);
const v5 = N.concat([v3, v4], 1);
return {out0: v5};
}, {v0: k.tensor([1, 352, 14, 14], "f32"), v1: k.tensor([1, 352, 14, 14], "f32"), v2: k.tensor([1, 386, 14, 14], "f32")});
