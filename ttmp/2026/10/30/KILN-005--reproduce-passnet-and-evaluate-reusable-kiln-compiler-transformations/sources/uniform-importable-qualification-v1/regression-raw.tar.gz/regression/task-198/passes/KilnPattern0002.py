from operator import iadd as kiln_iadd
import torch

def pattern(in_0, in_1):
    tmp_0 = torch.cat([in_0, in_1], dim=1)
    in_0 = in_1 = None
    tmp_1 = tmp_0[slice(None, None, None), slice(None, 120, None), slice(None, None, None), slice(None, None, None)]
    tmp_0 = None
    tmp_2 = tmp_1.mean((2, 3), keepdim=True)
    return (tmp_1, tmp_2)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_0, in_1):
 return (in_0, in_1, 2)
def replacement_func():
 return kiln_generated
