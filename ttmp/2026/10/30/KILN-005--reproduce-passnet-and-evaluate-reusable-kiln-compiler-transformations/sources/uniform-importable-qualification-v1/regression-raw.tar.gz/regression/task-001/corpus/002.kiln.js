project("passnet").program(({v0}) => {
const v1 = N.div(v0, 1.6817928305074292);
const v2 = N.transpose(v1, 3, 2);
return {out0: v2};
}, {v0: k.tensor([1, 4, 64, 8], "bf16")});
