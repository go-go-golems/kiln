from operator import iadd as kiln_iadd
import torch

def pattern(in_0):
    tmp_0 = in_0 / 1.6817928305074292
    in_0 = None
    tmp_1 = tmp_0.transpose(-1, -2)
    tmp_0 = None
    return tmp_1
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_0):
 return (in_0, 0)
def replacement_func():
 return kiln_generated
