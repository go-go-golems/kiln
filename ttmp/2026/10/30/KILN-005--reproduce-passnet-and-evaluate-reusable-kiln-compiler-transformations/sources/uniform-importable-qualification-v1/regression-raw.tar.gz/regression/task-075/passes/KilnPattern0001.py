from operator import iadd as kiln_iadd
import torch

def pattern(in_0, in_1, in_2):
    matmul = torch.matmul(in_0, in_1)
    in_0 = in_1 = None
    tmp_1 = matmul / 5.656854249492381
    matmul = None
    tmp_2 = torch.nn.functional.softmax(tmp_1, dim=-1)
    tmp_1 = None
    tmp_3 = torch.nn.functional.dropout(tmp_2, 0.0, False, False)
    tmp_2 = None
    matmul_1 = torch.matmul(tmp_3, in_2)
    tmp_3 = in_2 = None
    tmp_5 = matmul_1.permute(0, 2, 1, 3)
    matmul_1 = None
    tmp_6 = tmp_5.contiguous()
    tmp_5 = None
    tmp_7 = tmp_6.view((24, 256, 256))
    tmp_6 = None
    return tmp_7
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_0, in_1, in_2):
 return (in_0, in_1, in_2, 1)
def replacement_func():
 return kiln_generated
