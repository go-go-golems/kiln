from operator import iadd as kiln_iadd
import torch
from torch import device

def pattern(in_0):
    tmp_0 = torch.zeros((1, 133, 133), device=device(type='cuda', index=0))
    tmp_1 = tmp_0[slice(None, None, None), slice(-5, None, None), slice(None, None, None)]
    tmp_2 = tmp_1.fill_(1)
    tmp_3 = tmp_0[slice(None, None, None), slice(None, None, None), slice(-5, None, None)]
    tmp_4 = tmp_3.fill_(1)
    tmp_5 = in_0.reshape(1, 19, 7, 19, 7, 128)
    tmp_6 = tmp_5.transpose(2, 3)
    tmp_7 = tmp_0.reshape(1, 19, 7, 19, 7)
    tmp_8 = tmp_7.transpose(2, 3)
    tmp_9 = tmp_8.reshape(1, 361, 49)
    tmp_10 = tmp_9.unsqueeze(2)
    tmp_11 = tmp_9.unsqueeze(3)
    tmp_12 = tmp_10 - tmp_11
    tmp_13 = tmp_12 != 0
    tmp_14 = tmp_12.masked_fill(tmp_13, -1000.0)
    tmp_15 = tmp_12 == 0
    tmp_16 = tmp_14.masked_fill(tmp_15, 0.0)
    return (tmp_16, tmp_6, tmp_2, tmp_4)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_0):
 return (in_0, 1)
def replacement_func():
 return kiln_generated
