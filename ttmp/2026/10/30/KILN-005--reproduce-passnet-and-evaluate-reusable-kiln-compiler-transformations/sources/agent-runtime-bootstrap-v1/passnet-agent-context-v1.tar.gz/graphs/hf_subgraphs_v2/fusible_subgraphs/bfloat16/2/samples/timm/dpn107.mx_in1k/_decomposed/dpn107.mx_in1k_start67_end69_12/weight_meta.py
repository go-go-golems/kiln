class Program_weight_tensor_meta_L_self_modules_features_modules_conv3_1_modules_c1x1_w_s2_modules_conv_parameters_weight_:
	name = "in_0"
	original_name = "L_self_modules_features_modules_conv3_1_modules_c1x1_w_s2_modules_conv_parameters_weight_"
	shape = [640, 376, 1, 1]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.030


class Program_weight_tensor_meta_x_30:
	name = "in_1"
	original_name = "x_30"
	shape = [1, 376, 96, 96]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.002
	std = 0.003
