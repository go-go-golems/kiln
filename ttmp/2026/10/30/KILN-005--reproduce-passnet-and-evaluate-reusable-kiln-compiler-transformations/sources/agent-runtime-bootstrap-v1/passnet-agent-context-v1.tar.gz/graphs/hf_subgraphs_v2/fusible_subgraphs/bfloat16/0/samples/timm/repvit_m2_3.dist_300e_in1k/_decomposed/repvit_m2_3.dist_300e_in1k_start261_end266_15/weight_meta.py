class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_token_mixer_modules_bn_buffers_running_mean_:
	name = "in_0"
	original_name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_token_mixer_modules_bn_buffers_running_mean_"
	shape = [320]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_token_mixer_modules_bn_buffers_running_var_:
	name = "in_1"
	original_name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_token_mixer_modules_bn_buffers_running_var_"
	shape = [320]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 1.000
	std = 0.000
	min_val = 0


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_token_mixer_modules_bn_parameters_bias_:
	name = "in_2"
	original_name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_token_mixer_modules_bn_parameters_bias_"
	shape = [320]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_token_mixer_modules_bn_parameters_weight_:
	name = "in_3"
	original_name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_token_mixer_modules_bn_parameters_weight_"
	shape = [320]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 1.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_token_mixer_modules_conv1_parameters_bias_:
	name = "in_4"
	original_name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_token_mixer_modules_conv1_parameters_bias_"
	shape = [320]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.006
	std = 0.552


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_token_mixer_modules_conv1_parameters_weight_:
	name = "in_5"
	original_name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_token_mixer_modules_conv1_parameters_weight_"
	shape = [320, 1, 1, 1]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.039
	std = 0.593


class Program_weight_tensor_meta_input_130:
	name = "in_6"
	original_name = "input_130"
	shape = [1, 320, 14, 14]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.016
	std = 0.134


class Program_weight_tensor_meta_input_132:
	name = "in_7"
	original_name = "input_132"
	shape = [1, 320, 14, 14]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.001
	std = 0.016
