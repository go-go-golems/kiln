class Program_weight_tensor_meta_sym_sum:
	name = "in_0"
	original_name = "sym_sum"
	shape = []
	dtype = "torch.int64"
	device = "cuda:0"
	mean = None
	std = None
	data = [3]


class Program_weight_tensor_meta_x_67:
	name = "in_1"
	original_name = "x_67"
	shape = [1, 384, 12, 12]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.100
