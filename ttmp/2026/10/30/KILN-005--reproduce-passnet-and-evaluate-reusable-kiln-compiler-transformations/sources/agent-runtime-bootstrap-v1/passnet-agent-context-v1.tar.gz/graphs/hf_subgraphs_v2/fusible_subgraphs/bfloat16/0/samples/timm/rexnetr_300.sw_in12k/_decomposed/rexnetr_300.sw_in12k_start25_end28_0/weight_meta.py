class Program_weight_tensor_meta_getitem:
	name = "in_0"
	original_name = "getitem"
	shape = [1, 80, 56, 56]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100


class Program_weight_tensor_meta_x_15:
	name = "in_1"
	original_name = "x_15"
	shape = [1, 80, 56, 56]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.100


class Program_weight_tensor_meta_x_23:
	name = "in_2"
	original_name = "x_23"
	shape = [1, 112, 56, 56]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100
