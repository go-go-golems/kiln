class Program_weight_tensor_meta_L_input_ids_:
	name = "in_0"
	original_name = "L_input_ids_"
	shape = [1, 64]
	dtype = "torch.int64"
	device = "cuda:0"
	mean = None
	std = None
	data = [65, 29782, 8035, 419, 1074, 385, 8026, 31451, 28871, 114, 66, 65, 29782, 8035, 419, 1074, 385, 8026, 31451, 28871, 114, 66, 65, 29782, 8035, 419, 1074, 385, 8026, 31451, 28871, 114, 66, 65, 29782, 8035, 419, 1074, 385, 8026, 31451, 28871, 114, 66, 65, 29782, 8035, 419, 1074, 385, 8026, 31451, 28871, 114, 66, 65, 29782, 8035, 419, 1074, 385, 8026, 31451, 28871]


class Program_weight_tensor_meta_L_self_modules_embeddings_modules_LayerNorm_parameters_bias_:
	name = "in_1"
	original_name = "L_self_modules_embeddings_modules_LayerNorm_parameters_bias_"
	shape = [768]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_embeddings_modules_LayerNorm_parameters_weight_:
	name = "in_2"
	original_name = "L_self_modules_embeddings_modules_LayerNorm_parameters_weight_"
	shape = [768]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 1.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_embeddings_modules_position_embeddings_parameters_weight_:
	name = "in_3"
	original_name = "L_self_modules_embeddings_modules_position_embeddings_parameters_weight_"
	shape = [4096, 768]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.020


class Program_weight_tensor_meta_L_self_modules_embeddings_modules_token_type_embeddings_parameters_weight_:
	name = "in_4"
	original_name = "L_self_modules_embeddings_modules_token_type_embeddings_parameters_weight_"
	shape = [2, 768]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.020


class Program_weight_tensor_meta_L_self_modules_embeddings_modules_word_embeddings_parameters_weight_:
	name = "in_5"
	original_name = "L_self_modules_embeddings_modules_word_embeddings_parameters_weight_"
	shape = [50358, 768]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.020


class Program_weight_tensor_meta_L_token_type_ids_:
	name = "in_6"
	original_name = "L_token_type_ids_"
	shape = [1, 64]
	dtype = "torch.int64"
	device = "cuda:0"
	mean = None
	std = None
	data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]


class Program_weight_tensor_meta_getitem_2:
	name = "in_7"
	original_name = "getitem_2"
	shape = [1, 64]
	dtype = "torch.int64"
	device = "cuda:0"
	mean = None
	std = None
	max_val = 4038
	min_val = 12
