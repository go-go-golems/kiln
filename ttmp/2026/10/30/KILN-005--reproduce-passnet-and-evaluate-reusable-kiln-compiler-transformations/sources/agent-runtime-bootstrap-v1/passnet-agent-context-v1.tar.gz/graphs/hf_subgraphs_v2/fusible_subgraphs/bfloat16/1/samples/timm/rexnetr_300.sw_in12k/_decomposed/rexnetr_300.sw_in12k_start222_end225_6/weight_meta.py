class Program_weight_tensor_meta_getitem_16:
	name = "in_0"
	original_name = "getitem_16"
	shape = [1, 448, 8, 8]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100


class Program_weight_tensor_meta_x_121:
	name = "in_1"
	original_name = "x_121"
	shape = [1, 448, 8, 8]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.100


class Program_weight_tensor_meta_x_130:
	name = "in_2"
	original_name = "x_130"
	shape = [1, 480, 8, 8]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100
