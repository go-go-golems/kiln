class Program_weight_tensor_meta_pairwise_weight:
	name = "in_0"
	original_name = "pairwise_weight"
	shape = [2, 4096, 4096]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100
