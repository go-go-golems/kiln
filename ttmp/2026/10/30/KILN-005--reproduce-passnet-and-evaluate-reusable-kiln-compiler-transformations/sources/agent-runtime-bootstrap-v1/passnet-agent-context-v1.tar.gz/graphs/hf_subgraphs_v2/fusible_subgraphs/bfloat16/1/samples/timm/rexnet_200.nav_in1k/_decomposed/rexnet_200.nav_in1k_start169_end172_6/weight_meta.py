class Program_weight_tensor_meta_getitem_12:
	name = "in_0"
	original_name = "getitem_12"
	shape = [1, 234, 16, 16]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100


class Program_weight_tensor_meta_x_101:
	name = "in_1"
	original_name = "x_101"
	shape = [1, 257, 16, 16]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100


class Program_weight_tensor_meta_x_92:
	name = "in_2"
	original_name = "x_92"
	shape = [1, 234, 16, 16]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.100
