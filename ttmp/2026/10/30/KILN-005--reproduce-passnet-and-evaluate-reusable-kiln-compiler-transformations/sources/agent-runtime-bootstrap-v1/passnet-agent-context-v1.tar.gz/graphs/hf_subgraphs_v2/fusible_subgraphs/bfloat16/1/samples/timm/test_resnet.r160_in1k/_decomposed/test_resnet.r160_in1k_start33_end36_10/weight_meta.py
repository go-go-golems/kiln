class Program_weight_tensor_meta_L_self_modules_layer3_modules_0_modules_bn3_buffers_running_mean_:
	name = "in_0"
	original_name = "L_self_modules_layer3_modules_0_modules_bn3_buffers_running_mean_"
	shape = [192]
	dtype = "torch.bfloat16"
	device = "cpu"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_layer3_modules_0_modules_bn3_buffers_running_var_:
	name = "in_1"
	original_name = "L_self_modules_layer3_modules_0_modules_bn3_buffers_running_var_"
	shape = [192]
	dtype = "torch.bfloat16"
	device = "cpu"
	mean = 1.000
	std = 0.000
	min_val = 0


class Program_weight_tensor_meta_L_self_modules_layer3_modules_0_modules_bn3_parameters_bias_:
	name = "in_2"
	original_name = "L_self_modules_layer3_modules_0_modules_bn3_parameters_bias_"
	shape = [192]
	dtype = "torch.bfloat16"
	device = "cpu"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_layer3_modules_0_modules_bn3_parameters_weight_:
	name = "in_3"
	original_name = "L_self_modules_layer3_modules_0_modules_bn3_parameters_weight_"
	shape = [192]
	dtype = "torch.bfloat16"
	device = "cpu"
	mean = 0.000
	std = 0.050


class Program_weight_tensor_meta_L_self_modules_layer3_modules_0_modules_conv3_parameters_weight_:
	name = "in_4"
	original_name = "L_self_modules_layer3_modules_0_modules_conv3_parameters_weight_"
	shape = [192, 48, 1, 1]
	dtype = "torch.bfloat16"
	device = "cpu"
	mean = 0.001
	std = 0.102


class Program_weight_tensor_meta_x_16:
	name = "in_5"
	original_name = "x_16"
	shape = [1, 48, 32, 32]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.001
	std = 0.001


class Program_weight_tensor_meta_x_22:
	name = "in_6"
	original_name = "x_22"
	shape = [1, 48, 16, 16]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.100
