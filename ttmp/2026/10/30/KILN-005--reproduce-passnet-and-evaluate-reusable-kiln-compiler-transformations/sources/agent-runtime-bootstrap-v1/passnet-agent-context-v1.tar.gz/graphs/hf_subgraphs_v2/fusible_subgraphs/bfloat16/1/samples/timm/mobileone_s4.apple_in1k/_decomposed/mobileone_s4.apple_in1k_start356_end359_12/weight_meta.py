class Program_weight_tensor_meta_x_186:
	name = "in_0"
	original_name = "x_186"
	shape = [1, 2048, 8, 8]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100
