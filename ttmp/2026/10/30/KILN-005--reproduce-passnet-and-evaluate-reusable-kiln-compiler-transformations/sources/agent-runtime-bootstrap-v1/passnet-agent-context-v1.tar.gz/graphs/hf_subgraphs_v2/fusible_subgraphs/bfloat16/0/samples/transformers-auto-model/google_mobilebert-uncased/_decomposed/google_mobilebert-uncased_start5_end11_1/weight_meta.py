class Program_weight_tensor_meta_L_input_ids_:
	name = "in_0"
	original_name = "L_input_ids_"
	shape = [1, 64]
	dtype = "torch.int64"
	device = "cuda:0"
	mean = None
	std = None
	data = [101, 10629, 7159, 2003, 2109, 2000, 14817, 15078, 19287, 1012, 102, 101, 10629, 7159, 2003, 2109, 2000, 14817, 15078, 19287, 1012, 102, 101, 10629, 7159, 2003, 2109, 2000, 14817, 15078, 19287, 1012, 102, 101, 10629, 7159, 2003, 2109, 2000, 14817, 15078, 19287, 1012, 102, 101, 10629, 7159, 2003, 2109, 2000, 14817, 15078, 19287, 1012, 102, 101, 10629, 7159, 2003, 2109, 2000, 14817, 15078, 19287]


class Program_weight_tensor_meta_L_self_modules_embeddings_modules_word_embeddings_parameters_weight_:
	name = "in_1"
	original_name = "L_self_modules_embeddings_modules_word_embeddings_parameters_weight_"
	shape = [30522, 128]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.002
	std = 0.147
