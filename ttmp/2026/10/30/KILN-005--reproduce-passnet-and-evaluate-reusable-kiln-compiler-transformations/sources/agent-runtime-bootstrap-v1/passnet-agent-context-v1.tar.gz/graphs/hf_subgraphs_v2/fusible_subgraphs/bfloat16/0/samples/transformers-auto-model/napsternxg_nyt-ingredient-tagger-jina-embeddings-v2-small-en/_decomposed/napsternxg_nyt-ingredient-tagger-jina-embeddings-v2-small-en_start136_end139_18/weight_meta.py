class Program_weight_tensor_meta_gated_3:
	name = "in_0"
	original_name = "gated_3"
	shape = [1, 64, 2048]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.089


class Program_weight_tensor_meta_non_gated_3:
	name = "in_1"
	original_name = "non_gated_3"
	shape = [1, 64, 2048]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.002
	std = 0.092
