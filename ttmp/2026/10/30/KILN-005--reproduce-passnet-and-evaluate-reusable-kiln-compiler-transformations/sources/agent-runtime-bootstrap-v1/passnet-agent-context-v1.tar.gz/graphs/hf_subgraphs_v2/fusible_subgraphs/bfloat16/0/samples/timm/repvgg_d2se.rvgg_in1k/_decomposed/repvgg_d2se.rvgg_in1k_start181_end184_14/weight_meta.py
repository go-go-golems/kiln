class Program_weight_tensor_meta_x_101:
	name = "in_0"
	original_name = "x_101"
	shape = [1, 320, 28, 28]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.006
	std = 0.020


class Program_weight_tensor_meta_x_103:
	name = "in_1"
	original_name = "x_103"
	shape = [1, 320, 28, 28]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.003
	std = 0.018


class Program_weight_tensor_meta_x_99:
	name = "in_2"
	original_name = "x_99"
	shape = [1, 320, 28, 28]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.006
	std = 0.020
