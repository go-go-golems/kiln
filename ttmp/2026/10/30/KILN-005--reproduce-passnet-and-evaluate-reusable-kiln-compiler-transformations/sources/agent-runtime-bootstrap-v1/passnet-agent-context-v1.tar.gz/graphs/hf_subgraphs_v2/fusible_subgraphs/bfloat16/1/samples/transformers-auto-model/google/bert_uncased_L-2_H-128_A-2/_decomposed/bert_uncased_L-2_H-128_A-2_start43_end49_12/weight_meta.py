class Program_weight_tensor_meta_L_self_modules_encoder_modules_layer_modules_1_modules_attention_modules_self_modules_value_parameters_bias_:
	name = "in_0"
	original_name = "L_self_modules_encoder_modules_layer_modules_1_modules_attention_modules_self_modules_value_parameters_bias_"
	shape = [128]
	dtype = "torch.bfloat16"
	device = "cpu"
	mean = -0.001
	std = 0.067


class Program_weight_tensor_meta_L_self_modules_encoder_modules_layer_modules_1_modules_attention_modules_self_modules_value_parameters_weight_:
	name = "in_1"
	original_name = "L_self_modules_encoder_modules_layer_modules_1_modules_attention_modules_self_modules_value_parameters_weight_"
	shape = [128, 128]
	dtype = "torch.bfloat16"
	device = "cpu"
	mean = 0.000
	std = 0.099


class Program_weight_tensor_meta_extended_attention_mask:
	name = "in_2"
	original_name = "extended_attention_mask"
	shape = [1, 1, 512, 512]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.100


class Program_weight_tensor_meta_hidden_states_7:
	name = "in_3"
	original_name = "hidden_states_7"
	shape = [1, 512, 128]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.008
	std = 1.243


class Program_weight_tensor_meta_key_layer_1:
	name = "in_4"
	original_name = "key_layer_1"
	shape = [1, 2, 512, 64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.003
	std = 0.203


class Program_weight_tensor_meta_query_layer_1:
	name = "in_5"
	original_name = "query_layer_1"
	shape = [1, 2, 512, 64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.044
	std = 0.293
