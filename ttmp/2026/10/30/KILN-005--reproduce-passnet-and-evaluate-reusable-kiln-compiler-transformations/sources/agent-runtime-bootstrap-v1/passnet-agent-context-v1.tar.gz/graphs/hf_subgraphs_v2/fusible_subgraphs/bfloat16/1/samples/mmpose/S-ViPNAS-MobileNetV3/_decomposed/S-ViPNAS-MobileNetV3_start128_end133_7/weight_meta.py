class Program_weight_tensor_meta_L_self_modules_backbone_modules_layer10_modules_se_modules_conv2_modules_conv_parameters_bias_:
	name = "in_0"
	original_name = "L_self_modules_backbone_modules_layer10_modules_se_modules_conv2_modules_conv_parameters_bias_"
	shape = [400]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.004
	std = 0.071


class Program_weight_tensor_meta_L_self_modules_backbone_modules_layer10_modules_se_modules_conv2_modules_conv_parameters_weight_:
	name = "in_1"
	original_name = "L_self_modules_backbone_modules_layer10_modules_se_modules_conv2_modules_conv_parameters_weight_"
	shape = [400, 100, 1, 1]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.003
	std = 0.085


class Program_weight_tensor_meta_x_102:
	name = "in_2"
	original_name = "x_102"
	shape = [4, 400, 8, 8]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.005
	std = 0.037


class Program_weight_tensor_meta_x_104:
	name = "in_3"
	original_name = "x_104"
	shape = [4, 100, 1, 1]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.002
	std = 0.004
