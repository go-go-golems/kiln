class Program_weight_tensor_meta_L_self_modules_blocks_modules_2_modules_0_modules_bn2_buffers_running_mean_:
	name = "in_0"
	original_name = "L_self_modules_blocks_modules_2_modules_0_modules_bn2_buffers_running_mean_"
	shape = [288]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_blocks_modules_2_modules_0_modules_bn2_buffers_running_var_:
	name = "in_1"
	original_name = "L_self_modules_blocks_modules_2_modules_0_modules_bn2_buffers_running_var_"
	shape = [288]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 1.000
	std = 0.000
	min_val = 0


class Program_weight_tensor_meta_L_self_modules_blocks_modules_2_modules_0_modules_bn2_parameters_bias_:
	name = "in_2"
	original_name = "L_self_modules_blocks_modules_2_modules_0_modules_bn2_parameters_bias_"
	shape = [288]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_blocks_modules_2_modules_0_modules_bn2_parameters_weight_:
	name = "in_3"
	original_name = "L_self_modules_blocks_modules_2_modules_0_modules_bn2_parameters_weight_"
	shape = [288]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 1.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_blocks_modules_2_modules_0_modules_conv_dw_modules_2_parameters_weight_:
	name = "in_4"
	original_name = "L_self_modules_blocks_modules_2_modules_0_modules_conv_dw_modules_2_parameters_weight_"
	shape = [72, 1, 7, 7]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.199


class Program_weight_tensor_meta_L_self_modules_blocks_modules_2_modules_0_modules_conv_dw_modules_3_parameters_weight_:
	name = "in_5"
	original_name = "L_self_modules_blocks_modules_2_modules_0_modules_conv_dw_modules_3_parameters_weight_"
	shape = [72, 1, 9, 9]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.002
	std = 0.158


class Program_weight_tensor_meta_conv2d_16:
	name = "in_6"
	original_name = "conv2d_16"
	shape = [1, 72, 32, 32]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.100


class Program_weight_tensor_meta_conv2d_17:
	name = "in_7"
	original_name = "conv2d_17"
	shape = [1, 72, 32, 32]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.100


class Program_weight_tensor_meta_getitem_13:
	name = "in_8"
	original_name = "getitem_13"
	shape = [1, 72, 64, 64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.100


class Program_weight_tensor_meta_getitem_14:
	name = "in_9"
	original_name = "getitem_14"
	shape = [1, 72, 64, 64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100
