class Program_weight_tensor_meta_L_input_ids_:
	name = "in_0"
	original_name = "L_input_ids_"
	shape = [1, 64]
	dtype = "torch.int64"
	device = "cuda:0"
	mean = None
	std = None
	data = [2, 49, 791, 796, 790, 800, 799, 805, 803, 51, 801, 63, 801, 805, 810, 62, 809, 47, 811, 803, 791, 796, 804, 803, 45, 809, 802, 790, 794, 803, 796, 803, 792, 809, 799, 796, 793, 49, 791, 796, 790, 800, 801, 18, 3, 2, 49, 791, 796, 790, 800, 799, 805, 803, 51, 801, 63, 801, 805, 810, 62, 809, 47, 811]


class Program_weight_tensor_meta_L_self_modules_embeddings_modules_position_embeddings_parameters_weight_:
	name = "in_1"
	original_name = "L_self_modules_embeddings_modules_position_embeddings_parameters_weight_"
	shape = [512, 64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.020


class Program_weight_tensor_meta_L_self_modules_embeddings_modules_token_type_embeddings_parameters_weight_:
	name = "in_2"
	original_name = "L_self_modules_embeddings_modules_token_type_embeddings_parameters_weight_"
	shape = [16, 64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.020


class Program_weight_tensor_meta_L_self_modules_embeddings_modules_word_embeddings_parameters_weight_:
	name = "in_3"
	original_name = "L_self_modules_embeddings_modules_word_embeddings_parameters_weight_"
	shape = [1124, 64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.020


class Program_weight_tensor_meta_L_self_modules_encoder_modules_layer_modules_0_modules_attention_modules_ln_parameters_bias_:
	name = "in_4"
	original_name = "L_self_modules_encoder_modules_layer_modules_0_modules_attention_modules_ln_parameters_bias_"
	shape = [64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_encoder_modules_layer_modules_0_modules_attention_modules_ln_parameters_weight_:
	name = "in_5"
	original_name = "L_self_modules_encoder_modules_layer_modules_0_modules_attention_modules_ln_parameters_weight_"
	shape = [64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 1.000
	std = 0.000


class Program_weight_tensor_meta_L_token_type_ids_:
	name = "in_6"
	original_name = "L_token_type_ids_"
	shape = [1, 64]
	dtype = "torch.int64"
	device = "cuda:0"
	mean = None
	std = None
	data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]


class Program_weight_tensor_meta_getitem_2:
	name = "in_7"
	original_name = "getitem_2"
	shape = [1, 64]
	dtype = "torch.int64"
	device = "cuda:0"
	mean = None
	std = None
	max_val = 510
	min_val = 1
