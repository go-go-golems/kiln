class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_token_mixer_modules_bn_buffers_running_mean_:
	name = "in_0"
	original_name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_token_mixer_modules_bn_buffers_running_mean_"
	shape = [64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_token_mixer_modules_bn_buffers_running_var_:
	name = "in_1"
	original_name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_token_mixer_modules_bn_buffers_running_var_"
	shape = [64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 1.000
	std = 0.000
	min_val = 0


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_token_mixer_modules_bn_parameters_bias_:
	name = "in_2"
	original_name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_token_mixer_modules_bn_parameters_bias_"
	shape = [64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_token_mixer_modules_bn_parameters_weight_:
	name = "in_3"
	original_name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_token_mixer_modules_bn_parameters_weight_"
	shape = [64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 1.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_token_mixer_modules_conv1_parameters_bias_:
	name = "in_4"
	original_name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_token_mixer_modules_conv1_parameters_bias_"
	shape = [64]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.053
	std = 0.599


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_token_mixer_modules_conv1_parameters_weight_:
	name = "in_5"
	original_name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_token_mixer_modules_conv1_parameters_weight_"
	shape = [64, 1, 1, 1]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.045
	std = 0.556


class Program_weight_tensor_meta_input_4:
	name = "in_6"
	original_name = "input_4"
	shape = [1, 64, 56, 56]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.003


class Program_weight_tensor_meta_input_6:
	name = "in_7"
	original_name = "input_6"
	shape = [1, 64, 56, 56]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100
