class Program_weight_tensor_meta_x_11:
	name = "in_0"
	original_name = "x_11"
	shape = [8, 384, 56, 56]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100
