class Program_weight_tensor_meta_getitem_6:
	name = "in_0"
	original_name = "getitem_6"
	shape = [1, 109, 14, 14]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100


class Program_weight_tensor_meta_x_62:
	name = "in_1"
	original_name = "x_62"
	shape = [1, 109, 14, 14]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.100


class Program_weight_tensor_meta_x_71:
	name = "in_2"
	original_name = "x_71"
	shape = [1, 123, 14, 14]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100
