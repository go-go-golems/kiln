class Program_weight_tensor_meta_qk:
	name = "in_0"
	original_name = "qk"
	shape = [8, 17, 17]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.717
	std = 0.001
