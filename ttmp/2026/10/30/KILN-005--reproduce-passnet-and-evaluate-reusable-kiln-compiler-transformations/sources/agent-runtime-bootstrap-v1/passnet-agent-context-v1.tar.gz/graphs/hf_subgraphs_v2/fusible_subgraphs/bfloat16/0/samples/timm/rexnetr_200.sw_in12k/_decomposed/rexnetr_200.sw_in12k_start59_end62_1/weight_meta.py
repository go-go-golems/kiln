class Program_weight_tensor_meta_getitem_2:
	name = "in_0"
	original_name = "getitem_2"
	shape = [1, 104, 28, 28]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.100


class Program_weight_tensor_meta_x_33:
	name = "in_1"
	original_name = "x_33"
	shape = [1, 104, 28, 28]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.100


class Program_weight_tensor_meta_x_42:
	name = "in_2"
	original_name = "x_42"
	shape = [1, 120, 28, 28]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = 0.000
	std = 0.100
