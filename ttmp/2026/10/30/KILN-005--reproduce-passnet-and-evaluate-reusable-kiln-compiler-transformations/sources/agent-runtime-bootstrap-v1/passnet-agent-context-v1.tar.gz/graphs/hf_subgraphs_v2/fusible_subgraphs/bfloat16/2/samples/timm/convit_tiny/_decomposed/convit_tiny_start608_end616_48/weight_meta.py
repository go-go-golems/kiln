class Program_weight_tensor_meta_L_self_modules_blocks_modules_10_modules_attn_modules_qkv_parameters_weight_:
	name = "in_0"
	original_name = "L_self_modules_blocks_modules_10_modules_attn_modules_qkv_parameters_weight_"
	shape = [576, 192]
	dtype = "torch.bfloat16"
	device = "cpu"
	mean = -0.000
	std = 0.020


class Program_weight_tensor_meta_x_125:
	name = "in_1"
	original_name = "x_125"
	shape = [1, 197, 192]
	dtype = "torch.bfloat16"
	device = "cuda:0"
	mean = -0.000
	std = 0.999
