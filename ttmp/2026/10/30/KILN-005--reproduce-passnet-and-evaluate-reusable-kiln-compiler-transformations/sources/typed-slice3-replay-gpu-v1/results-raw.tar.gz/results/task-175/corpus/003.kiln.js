project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.cast(N.silu(N.cast(v0, "f32")), "bf16"), [32, 512, 20, 20], "bf16");
const v4 = N.expect(v1, [32, 256, 80, 80], "bf16");
const v5 = N.expect(v2, [32, 512, 40, 40], "bf16");
const v6 = N.expect(v3, [32, 512, 20, 20], "bf16");
return {out0: v4, out1: v5, out2: v6, __mut0: v3};
}, {v0: k.tensor([32, 512, 20, 20], "bf16"), v1: k.tensor([32, 256, 80, 80], "bf16"), v2: k.tensor([32, 512, 40, 40], "bf16")});
