from operator import iadd as kiln_iadd
import torch

def pattern(in_6, in_5, in_2, in_1, in_0):
    tmp_5 = in_6 + in_5
    tmp_6 = torch.nn.functional.layer_norm(tmp_5, (384,), in_2, in_1, 1e-12)
    tmp_10 = in_0.view(-1, 1)
    return (tmp_10, tmp_6)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_6, in_5, in_2, in_1, in_0):
 return (in_6, in_5, in_2, in_1, in_0, 0)
def replacement_func():
 return kiln_generated
