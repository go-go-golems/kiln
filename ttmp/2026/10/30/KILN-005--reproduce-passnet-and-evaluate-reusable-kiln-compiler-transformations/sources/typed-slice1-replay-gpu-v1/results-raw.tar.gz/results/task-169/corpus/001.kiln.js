project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.expect(N.cast(N.reshape(N.layer_norm(N.reshape(N.cast(v0, "f32"), [16, 768]), N.reshape(N.cast(v1, "f32"), [768]), N.reshape(N.cast(v2, "f32"), [768]), {"eps": 1e-12}), [1, 16, 768]), "bf16"), [1, 16, 768], "bf16");
const v5 = N.expect(N.reshape(v3, [1, 16, 1]), [1, 16, 1], "i64");
const v6 = N.expect(N.expand(v5, [1, 16, 768]), [1, 16, 768], "i64");
const v7 = N.expect(N.cast(v6, "f32"), [1, 16, 768], "f32");
const v8 = N.expect(N.mul(v4, v7), [1, 16, 768], "f32");
return {out0: v7, out1: v8, out2: v4};
}, {v0: k.tensor([1, 16, 768], "bf16"), v1: k.tensor([768], "bf16"), v2: k.tensor([768], "bf16"), v3: k.tensor([1, 16], "i64")});
