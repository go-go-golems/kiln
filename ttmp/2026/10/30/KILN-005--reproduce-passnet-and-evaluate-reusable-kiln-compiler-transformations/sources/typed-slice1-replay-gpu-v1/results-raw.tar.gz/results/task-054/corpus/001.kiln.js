project("passnet").program(({v0, v1}) => {
const v2 = N.expect(N.cast(v0, "f32"), [1, 10, 1024], "f32");
const v3 = N.expect(N.mul(v1, v2), [1, 10, 1024], "f32");
const v4 = N.expect(N.cast(N.reshape(N.sum(N.cast(v3, "f32"), 1, true), [1, 1024]), "f32"), [1, 1024], "f32");
const v5 = N.expect(N.cast(N.reshape(N.sum(N.cast(v2, "f32"), 1, true), [1, 1024]), "f32"), [1, 1024], "f32");
const v6 = N.expect(N.cast(N.select(N.lt(N.cast(v5, "f32"), N.cast(N.cast(N.const(1e-09, []), "f32"), "f32")), N.cast(N.cast(N.const(1e-09, []), "f32"), "f32"), N.cast(v5, "f32")), "f32"), [1, 1024], "f32");
const v7 = N.expect(N.div(v4, v6), [1, 1024], "f32");
const v8 = N.expect(N.concat([v7], 1), [1, 1024], "f32");
return {out0: v8};
}, {v0: k.tensor([1, 10, 1024], "i64"), v1: k.tensor([1, 10, 1024], "f16")});
