from operator import iadd as kiln_iadd
import torch

def pattern(in_3, in_2, in_1, in_0):
    tmp_4 = torch.nn.functional.layer_norm(in_3, (768,), in_2, in_1, 1e-12)
    tmp_5 = in_0.unsqueeze(-1)
    tmp_6 = tmp_5.expand_as(tmp_4)
    tmp_7 = tmp_6.float()
    tmp_8 = tmp_4 * tmp_7
    return (tmp_7, tmp_8, tmp_4)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_3, in_2, in_1, in_0):
 return (in_3, in_2, in_1, in_0, 0)
def replacement_func():
 return kiln_generated
