project("passnet").program(({v0, v1, v2, v3, v4}) => {
const v5 = N.expect(N.add(v0, v1), [1, 578, 384], "f16");
const v6 = N.expect(N.cast(N.reshape(N.layer_norm(N.reshape(N.cast(v5, "f32"), [578, 384]), N.reshape(N.cast(v2, "f32"), [384]), N.reshape(N.cast(v3, "f32"), [384]), {"eps": 1e-12}), [1, 578, 384]), "f16"), [1, 578, 384], "f16");
const v7 = N.expect(N.reshape(v4, [1, 1]), [1, 1], "i64");
return {out0: v7, out1: v6};
}, {v0: k.tensor([1, 578, 384], "f16"), v1: k.tensor([1, 578, 384], "f16"), v2: k.tensor([384], "f16"), v3: k.tensor([384], "f16"), v4: k.tensor([1, 1], "i64")});
