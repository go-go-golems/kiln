project("passnet").program(({v0, v1}) => {
const v2 = N.cast(N.silu(N.cast(v0, "f32")), "f16");
const v3_0 = N.slice(v2, 2, 0, 512);
const v3_1 = N.slice(v2, 2, 512, 1024);
const v3_2 = N.slice(v2, 2, 1024, 1152);
const v4 = v3_0;
const v5 = v3_1;
const v6 = v3_2;
const v7 = N.reshape(v6, [512, 17, 1, 128]);
const v8 = N.reshape(v1, [1, 1, 2, 128]);
return {out0: v8, out1: v4, out2: v7, out3: v5, __mut0: v2};
}, {v0: k.tensor([512, 17, 1152], "f16"), v1: k.tensor([2, 128], "f16")});
