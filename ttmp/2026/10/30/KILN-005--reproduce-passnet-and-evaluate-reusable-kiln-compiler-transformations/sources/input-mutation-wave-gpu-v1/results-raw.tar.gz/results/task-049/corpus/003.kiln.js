project("passnet").program(({v0}) => {
const v1 = N.relu(v0);
const v2 = N.maxPool2d(v1, {"kernel_size": [5, 5], "stride": [1, 1], "padding": [2, 2], "dilation": [1, 1], "ceil_mode": false, "return_indices": false});
const v3 = N.maxPool2d(v1, {"kernel_size": [5, 5], "stride": [1, 1], "padding": [2, 2], "dilation": [1, 1], "ceil_mode": false, "return_indices": false});
const v4 = N.maxPool2d(v1, {"kernel_size": [5, 5], "stride": [1, 1], "padding": [2, 2], "dilation": [1, 1], "ceil_mode": false, "return_indices": false});
const v5 = N.concat([v1, v2, v3, v4], 1);
return {out0: v5, __mut0: v1};
}, {v0: k.tensor([16, 256, 20, 20], "bf16")});
