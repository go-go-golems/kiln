from operator import iadd as kiln_iadd
import torch

def pattern(in_1, in_0):
    in_1 = kiln_iadd(in_1, in_0)
    in_2 = in_1
    in_1 = in_0 = None
    tmp_2 = in_2.transpose(1, 2)
    in_2 = None
    return tmp_2
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_1, in_0):
 return (in_1, in_0, 0)
def replacement_func():
 return kiln_generated
