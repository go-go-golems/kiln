project("passnet").program(({v0, v1}) => {
const v2 = N.add(v0, v1);
const v3 = N.cast(v2, "f32");
const v4 = N.cast(N.softmax(N.cast(v3, "f32"), 3), "f32");
const v5 = N.cast(v4, "f32");
const v6 = v5;
return {out0: v6, __mut0: v2};
}, {v0: k.tensor([2, 16, 64, 64], "f32"), v1: k.tensor([2, 16, 64, 64], "f32")});
