project("passnet").program(({v0, v1, v2}) => {
const v3 = N.conv2d(v0, v1, null, {"stride": [1, 1], "padding": [32, 0], "dilation": [1, 1], "groups": 4});
const v4 = N.add(v2, v3);
const v5 = N.transpose(v4, 1, 2);
const v6 = N.reshape(v5, [4, 512, 4, 8]);
const v7 = N.reshape(v6, [4, 512, 32]);
return {out0: v7, __mut2: v4};
}, {v0: k.tensor([4, 4, 512, 8], "bf16"), v1: k.tensor([4, 1, 65, 1], "bf16"), v2: k.tensor([4, 4, 512, 8], "bf16")});
