project("passnet").program(({v0}) => {
const v1 = N.cast(N.select(N.gt(N.select(N.lt(N.cast(v0, "f32"), N.cast(N.cast(N.const(0.0, []), "bf16"), "f32")), N.cast(N.cast(N.const(0.0, []), "bf16"), "f32"), N.cast(v0, "f32")), N.cast(N.cast(N.const(6.0, []), "bf16"), "f32")), N.cast(N.cast(N.const(6.0, []), "bf16"), "f32"), N.select(N.lt(N.cast(v0, "f32"), N.cast(N.cast(N.const(0.0, []), "bf16"), "f32")), N.cast(N.cast(N.const(0.0, []), "bf16"), "f32"), N.cast(v0, "f32"))), "bf16");
const v2 = N.adaptiveAvgPool2d(v1, [1, 1]);
const v3 = N.reshape(v2, [32, 1280]);
const v4 = N.reshape(v3, [32, 1280]);
return {out0: v4, __mut0: v1};
}, {v0: k.tensor([32, 1280, 6, 8], "bf16")});
