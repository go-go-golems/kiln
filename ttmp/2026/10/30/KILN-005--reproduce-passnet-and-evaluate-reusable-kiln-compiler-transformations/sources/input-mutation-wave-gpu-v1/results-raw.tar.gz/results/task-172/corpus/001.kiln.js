project("passnet").program(({v0, v1}) => {
const v2 = N.add(v0, v1);
const v3 = N.cast(v2, "f32");
const v4 = N.cast(N.softmax(N.cast(v3, "f32"), 3), "f32");
const v5 = N.cast(v4, "bf16");
const v6 = v5;
return {out0: v6, __mut0: v2};
}, {v0: k.tensor([1, 16, 16, 16], "bf16"), v1: k.tensor([1, 16, 16, 16], "bf16")});
