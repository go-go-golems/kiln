project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [1, 256, 4, 256], "bf16");
const v4 = N.expect(N.cast(N.silu(N.cast(v3, "f32")), "bf16"), [1, 256, 4, 256], "bf16");
const v5 = N.expect(v4, [1, 256, 4, 256], "bf16");
return {out0: v5};
}, {v0: k.tensor([1, 128, 4, 256], "bf16"), v1: k.tensor([256, 128, 1, 1], "bf16"), v2: k.tensor([256], "bf16")});
