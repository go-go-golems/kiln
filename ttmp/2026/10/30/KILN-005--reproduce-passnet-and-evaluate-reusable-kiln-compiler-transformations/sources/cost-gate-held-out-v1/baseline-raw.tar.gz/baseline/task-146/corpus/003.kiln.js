project("passnet").program(({v0, v1, v2, v3, v4}) => {
const v5 = N.expect(N.cast(N.matmul(N.cast(v0, "f32"), N.cast(v1, "f32")), "f16"), [4, 8, 8, 15], "f16");
const v6 = N.expect(N.reshape(v5, [32, 8, 15]), [32, 8, 15], "f16");
const v7 = N.expect(N.pad(v6, [0, 1], "constant", 0), [32, 8, 16], "f16");
const v8 = N.expect(N.reshape(v7, [32, 128]), [32, 128], "f16");
const v9 = N.expect(N.pad(v8, [0, 7], "constant", 0), [32, 135], "f16");
const v10 = N.expect(N.reshape(v9, [32, 9, 15]), [32, 9, 15], "f16");
const v11 = N.expect(N.reshape(N.slice(N.slice(v10, 1, 0, 8), 2, 7, 15), [32, 8, 8]), [32, 8, 8], "f16");
const v12 = N.expect(N.reshape(v11, [4, 8, 1, 8, 8]), [4, 8, 1, 8, 8], "f16");
const v13 = N.expect(N.expand(v12, [-1, -1, 8, -1, -1]), [4, 8, 8, 8, 8], "f16");
const v14 = N.expect(N.transpose(N.transpose(N.transpose(v13, 1, 3), 2, 3), 3, 4), [4, 8, 8, 8, 8], "f16");
const v15 = N.expect(N.add(v14, v2), [4, 8, 8, 8, 8], "f16");
const v16 = N.expect(N.reshape(v15, [4, 64, 64]), [4, 64, 64], "f16");
const v17 = N.expect(N.add(v3, v16), [4, 64, 64], "f16");
const v18 = N.expect(N.cast(N.softmax(N.cast(v17, "f32"), 2), "f16"), [4, 64, 64], "f16");
const v19 = N.expect(N.cast(N.matmul(N.cast(v18, "f32"), N.cast(v4, "f32")), "f16"), [4, 64, 128], "f16");
const v20 = N.expect(N.transpose(v19, 2, 1), [4, 128, 64], "f16");
return {out0: v20};
}, {v0: k.tensor([4, 8, 8, 128], "f16"), v1: k.tensor([128, 15], "f16"), v2: k.tensor([4, 8, 8, 8, 8], "f16"), v3: k.tensor([4, 64, 64], "f16"), v4: k.tensor([4, 64, 128], "f16")});
