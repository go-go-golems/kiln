project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.cast(N.matmul(N.cast(v0, "f32"), N.cast(v1, "f32")), "f32"), [1, 2, 4096, 256], "f32");
const v4 = N.expect(N.div(v3, 5.656854249492381), [1, 2, 4096, 256], "f32");
const v5 = N.expect(N.cast(N.softmax(N.cast(v4, "f32"), 3), "f32"), [1, 2, 4096, 256], "f32");
const v6 = N.expect(v5, [1, 2, 4096, 256], "f32");
const v7 = N.expect(N.cast(N.matmul(N.cast(v6, "f32"), N.cast(v2, "f32")), "f32"), [1, 2, 4096, 32], "f32");
const v8 = N.expect(N.transpose(v7, 1, 2), [1, 4096, 2, 32], "f32");
const v9 = N.expect(N.reshape(v8, [1, 4096, 2, 32]), [1, 4096, 2, 32], "f32");
const v10 = N.expect(N.reshape(v9, [1, 4096, 64]), [1, 4096, 64], "f32");
return {out0: v10};
}, {v0: k.tensor([1, 2, 4096, 32], "f32"), v1: k.tensor([1, 2, 32, 256], "f32"), v2: k.tensor([1, 2, 256, 32], "f32")});
