project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.cast(N.matmul(N.cast(v0, "f32"), N.cast(v1, "f32")), "bf16"), [1, 8, 785, 19], "bf16");
const v4 = N.expect(N.reshape(N.slice(v0, 2, 1, 785), [1, 8, 784, 19]), [1, 8, 784, 19], "bf16");
const v5 = N.expect(N.reshape(N.slice(v2, 2, 1, 785), [1, 8, 784, 19]), [1, 8, 784, 19], "bf16");
const v6 = N.expect(N.transpose(v5, 3, 2), [1, 8, 19, 784], "bf16");
const v7 = N.expect(N.reshape(v6, [1, 152, 28, 28]), [1, 152, 28, 28], "bf16");
const v8_0 = N.expect(N.slice(v7, 1, 0, 38), [1, 38, 28, 28], "bf16");
const v8_1 = N.expect(N.slice(v7, 1, 38, 95), [1, 57, 28, 28], "bf16");
const v8_2 = N.expect(N.slice(v7, 1, 95, 152), [1, 57, 28, 28], "bf16");
const v9 = N.expect(v8_0, [1, 38, 28, 28], "bf16");
const v10 = N.expect(v8_1, [1, 57, 28, 28], "bf16");
const v11 = N.expect(v8_2, [1, 57, 28, 28], "bf16");
return {out0: v3, out1: v9, out2: v10, out3: v11, out4: v4};
}, {v0: k.tensor([1, 8, 785, 19], "bf16"), v1: k.tensor([1, 8, 19, 19], "bf16"), v2: k.tensor([1, 8, 785, 19], "bf16")});
