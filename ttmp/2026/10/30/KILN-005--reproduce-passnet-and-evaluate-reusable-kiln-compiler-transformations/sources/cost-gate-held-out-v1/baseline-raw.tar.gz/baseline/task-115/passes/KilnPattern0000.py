from operator import iadd as kiln_iadd
import torch

def pattern(in_1, in_0, in_2):
    conv2d = torch.conv2d(in_1, in_0, None, (1, 1), (0, 0), (1, 1), 1)
    tmp_2 = torch.sigmoid(conv2d)
    tmp_3 = torch.nn.functional.interpolate(tmp_2, (64, 128), None, 'bilinear', False)
    tmp_4 = in_2 * tmp_3
    return tmp_4
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_1, in_0, in_2):
 return (in_1, in_0, in_2, 0)
def replacement_func():
 return kiln_generated
