project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [512, 1, 64, 48], "f32");
const v4 = N.expect(N.reshape(v3, [512, 1, 3072]), [512, 1, 3072], "f32");
const v5 = N.expect(N.cast(N.softmax(N.cast(v4, "f32"), 2), "f32"), [512, 1, 3072], "f32");
const v6 = N.expect(N.reshape(v5, [512, 1, 3072, 1]), [512, 1, 3072, 1], "f32");
return {out0: v6};
}, {v0: k.tensor([512, 80, 64, 48], "f32"), v1: k.tensor([1, 80, 1, 1], "f32"), v2: k.tensor([1], "f32")});
