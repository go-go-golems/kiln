project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [16, 256, 64, 64], "f16");
const v5 = N.expect(N.reshape(v4, [16, 256, 4096]), [16, 256, 4096], "f16");
const v6 = N.expect(N.cast(N.mul(N.sum(N.cast(v3, "f32"), 1, true), 0.000244140625), "f16"), [16, 1, 256], "f16");
return {out0: v6, out1: v5};
}, {v0: k.tensor([16, 512, 64, 64], "f16"), v1: k.tensor([256, 512, 1, 1], "f16"), v2: k.tensor([256], "f16"), v3: k.tensor([16, 4096, 256], "f16")});
