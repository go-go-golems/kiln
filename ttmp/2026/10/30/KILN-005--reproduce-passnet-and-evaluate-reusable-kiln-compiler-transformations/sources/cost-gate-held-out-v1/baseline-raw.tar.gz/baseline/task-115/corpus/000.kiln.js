project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.conv2d(v0, v1, null, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [1, 128, 1, 4], "f16");
const v4 = N.expect(N.cast(N.sigmoid(N.cast(v3, "f32")), "f16"), [1, 128, 1, 4], "f16");
const v5 = N.expect(N.resizeBilinear(v4, [64, 128]), [1, 128, 64, 128], "f16");
const v6 = N.expect(N.mul(v2, v5), [1, 128, 64, 128], "f16");
return {out0: v6};
}, {v0: k.tensor([1, 960, 1, 4], "f16"), v1: k.tensor([128, 960, 1, 1], "f16"), v2: k.tensor([1, 128, 64, 128], "f16")});
