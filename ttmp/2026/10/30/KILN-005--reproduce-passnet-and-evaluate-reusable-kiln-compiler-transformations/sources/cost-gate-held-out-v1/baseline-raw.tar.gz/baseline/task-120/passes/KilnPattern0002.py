from operator import iadd as kiln_iadd
import torch

def pattern(in_6, in_1, in_0, in_5, in_2, in_4, in_3):
    conv2d = torch.conv2d(in_6, in_1, in_0, (1, 1), (0, 0), (1, 1), 1)
    tmp_3 = torch.sigmoid(conv2d)
    tmp_4 = in_5 * tmp_3
    tmp_5 = torch.cat([in_2, in_4], dim=1)
    tmp_6 = torch.cat([in_3, tmp_4], dim=1)
    tmp_7 = tmp_5.view(8, 2, 20, 64, 48)
    tmp_8 = torch.transpose(tmp_7, 1, 2)
    tmp_9 = tmp_8.contiguous()
    tmp_10 = tmp_9.view(8, 40, 64, 48)
    tmp_11 = tmp_6.view(8, 2, 40, 32, 24)
    tmp_12 = torch.transpose(tmp_11, 1, 2)
    tmp_13 = tmp_12.contiguous()
    tmp_14 = tmp_13.view(8, 80, 32, 24)
    chunk = tmp_10.chunk(2, dim=1)
    tmp_16 = chunk[0]
    tmp_17 = chunk[1]
    chunk_1 = tmp_14.chunk(2, dim=1)
    tmp_19 = chunk_1[0]
    tmp_20 = chunk_1[1]
    return (tmp_16, tmp_19, tmp_17, tmp_20)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_6, in_1, in_0, in_5, in_2, in_4, in_3):
 return (in_6, in_1, in_0, in_5, in_2, in_4, in_3, 2)
def replacement_func():
 return kiln_generated
