project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [32, 1024, 1, 1], "bf16");
const v5 = N.expect(N.cast(N.sigmoid(N.cast(v4, "f32")), "bf16"), [32, 1024, 1, 1], "bf16");
const v6 = N.expect(N.mul(v3, v5), [32, 1024, 12, 12], "bf16");
const v7 = N.expect(N.cast(N.gelu(N.cast(v6, "f32"), "none"), "bf16"), [32, 1024, 12, 12], "bf16");
const v8 = N.expect(N.adaptiveAvgPool2d(v7, [1, 1]), [32, 1024, 1, 1], "bf16");
const v9 = N.expect(N.reshape(v8, [32, 1024]), [32, 1024], "bf16");
const v10 = N.expect(v9, [32, 1024], "bf16");
return {out0: v10};
}, {v0: k.tensor([32, 64, 1, 1], "bf16"), v1: k.tensor([1024, 64, 1, 1], "bf16"), v2: k.tensor([1024], "bf16"), v3: k.tensor([32, 1024, 12, 12], "bf16")});
