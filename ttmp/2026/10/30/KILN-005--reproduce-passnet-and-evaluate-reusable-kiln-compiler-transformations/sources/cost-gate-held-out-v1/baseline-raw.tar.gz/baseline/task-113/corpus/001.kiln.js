project("passnet").program(({v0, v1, v2, v3, v4}) => {
const v5 = N.expect(N.sub(v0, v1), [1, 4096, 32, 512], "bf16");
const v6 = N.expect(N.cast(N.square(N.cast(v5, "f32")), "bf16"), [1, 4096, 32, 512], "bf16");
const v7 = N.expect(N.cast(N.reshape(N.sum(N.cast(v6, "f32"), 3, true), [1, 4096, 32]), "bf16"), [1, 4096, 32], "bf16");
const v8 = N.expect(N.mul(v2, v7), [1, 4096, 32], "bf16");
const v9 = N.expect(N.cast(N.softmax(N.cast(v8, "f32"), 2), "bf16"), [1, 4096, 32], "bf16");
const v10 = N.expect(N.reshape(v3, [1, 1, 32, 512]), [1, 1, 32, 512], "bf16");
const v11 = N.expect(N.reshape(v4, [1, 4096, 1, 512]), [1, 4096, 1, 512], "bf16");
const v12 = N.expect(N.expand(v11, [1, 4096, 32, 512]), [1, 4096, 32, 512], "bf16");
const v13 = N.expect(N.reshape(v9, [1, 4096, 32, 1]), [1, 4096, 32, 1], "bf16");
const v14 = N.expect(N.sub(v12, v10), [1, 4096, 32, 512], "bf16");
return {out0: v14, out1: v13};
}, {v0: k.tensor([1, 4096, 32, 512], "bf16"), v1: k.tensor([1, 1, 32, 512], "bf16"), v2: k.tensor([1, 1, 32], "bf16"), v3: k.tensor([32, 512], "bf16"), v4: k.tensor([1, 4096, 512], "bf16")});
