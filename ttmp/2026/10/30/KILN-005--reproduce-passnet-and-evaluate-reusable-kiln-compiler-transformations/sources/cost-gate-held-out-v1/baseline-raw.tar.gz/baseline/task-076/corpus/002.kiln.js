project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [1, 128, 4, 256], "bf16");
const v5 = N.expect(v4, [1, 128, 4, 256], "bf16");
const v6 = N.expect(N.add(v5, v3), [1, 128, 4, 256], "bf16");
return {out0: v6};
}, {v0: k.tensor([1, 256, 4, 256], "bf16"), v1: k.tensor([128, 256, 1, 1], "bf16"), v2: k.tensor([128], "bf16"), v3: k.tensor([1, 128, 4, 256], "bf16")});
