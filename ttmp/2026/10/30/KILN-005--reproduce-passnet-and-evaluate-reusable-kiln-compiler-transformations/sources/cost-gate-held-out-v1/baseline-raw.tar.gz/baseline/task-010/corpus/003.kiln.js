project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [16, 1, 64, 64], "bf16");
const v4 = N.expect(N.reshape(v3, [16, 1, 4096]), [16, 1, 4096], "bf16");
const v5 = N.expect(N.cast(N.softmax(N.cast(v4, "f32"), 2), "bf16"), [16, 1, 4096], "bf16");
const v6 = N.expect(N.reshape(v5, [16, 1, 4096, 1]), [16, 1, 4096, 1], "bf16");
return {out0: v6};
}, {v0: k.tensor([16, 512, 64, 64], "bf16"), v1: k.tensor([1, 512, 1, 1], "bf16"), v2: k.tensor([1], "bf16")});
