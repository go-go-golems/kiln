project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.cast(N.matmul(N.cast(v0, "f32"), N.cast(v1, "f32")), "f16"), [1, 16, 257, 257], "f16");
const v4 = N.expect(N.mul(v3, 1.0), [1, 16, 257, 257], "f16");
const v5 = N.expect(N.cast(N.softmax(N.cast(N.cast(v4, "f32"), "f32"), 3), "f32"), [1, 16, 257, 257], "f32");
const v6 = N.expect(N.cast(v5, "f32"), [1, 16, 257, 257], "f32");
const v7 = N.expect(v6, [1, 16, 257, 257], "f32");
const v8 = N.expect(N.cast(v7, "f16"), [1, 16, 257, 257], "f16");
const v9 = N.expect(N.cast(N.matmul(N.cast(v8, "f32"), N.cast(v2, "f32")), "f16"), [1, 16, 257, 80], "f16");
const v10 = N.expect(N.transpose(v9, 1, 2), [1, 257, 16, 80], "f16");
const v11 = N.expect(N.reshape(v10, [1, 257, 16, 80]), [1, 257, 16, 80], "f16");
const v12 = N.expect(N.reshape(v11, [1, 257, 1280]), [1, 257, 1280], "f16");
const v13 = N.expect(N.reshape(v12, [1, 257, 1280]), [1, 257, 1280], "f16");
return {out0: v13};
}, {v0: k.tensor([1, 16, 257, 80], "f16"), v1: k.tensor([1, 16, 80, 257], "f16"), v2: k.tensor([1, 16, 257, 80], "f16")});
