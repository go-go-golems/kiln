const passnetProject = project("passnet").program(({v0, v1, v2, v3, v4, v5, v6, v7, v8}) => {
const v9 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [32, 64, 64, 64], "bf16");
const v10 = N.expect(v9, [32, 64, 64, 64], "bf16");
const v11 = N.expect(N.mul(v10, v3), [32, 64, 64, 64], "bf16");
const v12 = N.expect(N.add(v4, v11), [32, 64, 64, 64], "bf16");
const v13 = N.expect(N.cast(N.add(N.mul(N.div(N.sub(N.cast(v12, "f32"), N.reshape(N.cast(v5, "f32"), [1, 64, 1, 1])), N.sqrt(N.add(N.reshape(N.cast(v6, "f32"), [1, 64, 1, 1]), 1e-05))), N.reshape(N.cast(v7, "f32"), [1, 64, 1, 1])), N.reshape(N.cast(v8, "f32"), [1, 64, 1, 1])), "bf16"), [32, 64, 64, 64], "bf16");
return {out0: v13, out1: v12};
}, {v0: k.tensor([32, 256, 64, 64], "bf16"), v1: k.tensor([64, 256, 1, 1], "bf16"), v2: k.tensor([64], "bf16"), v3: k.tensor([64, 1, 1], "bf16"), v4: k.tensor([32, 64, 64, 64], "bf16"), v5: k.tensor([64], "bf16"), v6: k.tensor([64], "bf16"), v7: k.tensor([64], "bf16"), v8: k.tensor([64], "bf16")});
const passnetReferenceInputs = passnetProject.inputsFor(passnetProject.graph(), {names: ["v6"]});
for (let i=0; i<passnetReferenceInputs.v6.data.length; i++) passnetReferenceInputs.v6.data[i] = Math.abs(passnetReferenceInputs.v6.data[i]) + 0.1;
passnetProject.data(passnetReferenceInputs);
