project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [1, 1], "dilation": [1, 1], "groups": 128}), [1, 128, 56, 56], "f32");
const v4 = N.expect(N.cast(N.gelu(N.cast(v3, "f32"), "none"), "f32"), [1, 128, 56, 56], "f32");
const v5 = N.expect(v4, [1, 128, 56, 56], "f32");
return {out0: v5};
}, {v0: k.tensor([1, 128, 56, 56], "f32"), v1: k.tensor([128, 1, 3, 3], "f32"), v2: k.tensor([128], "f32")});
