project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.cast(N.matmul(N.cast(v0, "f32"), N.cast(v1, "f32")), "bf16"), [4, 4, 16, 16], "bf16");
const v4 = N.expect(N.div(v3, 6.0), [4, 4, 16, 16], "bf16");
const v5 = N.expect(N.cast(N.softmax(N.cast(v4, "f32"), 3), "bf16"), [4, 4, 16, 16], "bf16");
const v6 = N.expect(v5, [4, 4, 16, 16], "bf16");
const v7 = N.expect(N.cast(N.matmul(N.cast(v6, "f32"), N.cast(v2, "f32")), "bf16"), [4, 4, 16, 36], "bf16");
const v8 = N.expect(N.transpose(v7, 1, 2), [4, 16, 4, 36], "bf16");
const v9 = N.expect(N.reshape(v8, [4, 16, 4, 36]), [4, 16, 4, 36], "bf16");
const v10 = N.expect(N.reshape(v9, [4, 16, 144]), [4, 16, 144], "bf16");
return {out0: v10};
}, {v0: k.tensor([4, 4, 16, 36], "bf16"), v1: k.tensor([4, 4, 36, 16], "bf16"), v2: k.tensor([4, 4, 16, 36], "bf16")});
