project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [32, 256, 64, 64], "f32");
const v4 = N.expect(N.cast(N.gelu(N.cast(v3, "f32"), "none"), "f32"), [32, 256, 64, 64], "f32");
const v5 = N.expect(v4, [32, 256, 64, 64], "f32");
return {out0: v5};
}, {v0: k.tensor([32, 64, 64, 64], "f32"), v1: k.tensor([256, 64, 1, 1], "f32"), v2: k.tensor([256], "f32")});
