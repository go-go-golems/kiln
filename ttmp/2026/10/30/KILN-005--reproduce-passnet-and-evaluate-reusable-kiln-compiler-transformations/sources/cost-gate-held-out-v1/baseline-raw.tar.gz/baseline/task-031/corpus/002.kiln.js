project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.cast(N.matmul(N.cast(v0, "f32"), N.cast(v1, "f32")), "bf16"), [1, 8, 197, 27], "bf16");
const v4 = N.expect(N.reshape(N.slice(v0, 2, 1, 197), [1, 8, 196, 27]), [1, 8, 196, 27], "bf16");
const v5 = N.expect(N.reshape(N.slice(v2, 2, 1, 197), [1, 8, 196, 27]), [1, 8, 196, 27], "bf16");
const v6 = N.expect(N.transpose(v5, 3, 2), [1, 8, 27, 196], "bf16");
const v7 = N.expect(N.reshape(v6, [1, 216, 14, 14]), [1, 216, 14, 14], "bf16");
const v8_0 = N.expect(N.slice(v7, 1, 0, 54), [1, 54, 14, 14], "bf16");
const v8_1 = N.expect(N.slice(v7, 1, 54, 135), [1, 81, 14, 14], "bf16");
const v8_2 = N.expect(N.slice(v7, 1, 135, 216), [1, 81, 14, 14], "bf16");
const v9 = N.expect(v8_0, [1, 54, 14, 14], "bf16");
const v10 = N.expect(v8_1, [1, 81, 14, 14], "bf16");
const v11 = N.expect(v8_2, [1, 81, 14, 14], "bf16");
return {out0: v3, out1: v9, out2: v10, out3: v11, out4: v4};
}, {v0: k.tensor([1, 8, 197, 27], "bf16"), v1: k.tensor([1, 8, 27, 27], "bf16"), v2: k.tensor([1, 8, 197, 27], "bf16")});
