project("passnet").program(({v0, v1, v2, v3, v4, v5}) => {
const v6 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [64, 128, 16, 16], "f32");
const v7 = N.expect(N.resizeBilinear(v3, [64, 64]), [64, 128, 64, 64], "f32");
const v8 = N.expect(N.cast(N.sigmoid(N.cast(v7, "f32")), "f32"), [64, 128, 64, 64], "f32");
const v9 = N.expect(N.mul(v4, v8), [64, 128, 64, 64], "f32");
const v10 = N.expect(N.cast(N.sigmoid(N.cast(v6, "f32")), "f32"), [64, 128, 16, 16], "f32");
const v11 = N.expect(N.mul(v5, v10), [64, 128, 16, 16], "f32");
const v12 = N.expect(N.resizeBilinear(v11, [64, 64]), [64, 128, 64, 64], "f32");
const v13 = N.expect(N.add(v9, v12), [64, 128, 64, 64], "f32");
return {out0: v13};
}, {v0: k.tensor([64, 128, 16, 16], "f32"), v1: k.tensor([128, 128, 1, 1], "f32"), v2: k.tensor([128], "f32"), v3: k.tensor([64, 128, 16, 16], "f32"), v4: k.tensor([64, 128, 64, 64], "f32"), v5: k.tensor([64, 128, 16, 16], "f32")});
