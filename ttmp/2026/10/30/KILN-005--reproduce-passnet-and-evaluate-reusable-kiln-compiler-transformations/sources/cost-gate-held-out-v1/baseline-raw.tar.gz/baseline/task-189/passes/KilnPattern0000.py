from operator import iadd as kiln_iadd
import torch

def pattern(in_0, in_1, in_2, in_3):
    tmp_0 = torch.cat([in_0, in_1, in_2, in_3], 1)
    tmp_1 = torch.nn.functional.adaptive_avg_pool2d(tmp_0, (1, 1))
    tmp_2 = torch.nn.functional.dropout(tmp_1, 0.5, False, False)
    tmp_3 = torch.flatten(tmp_2, 1)
    return tmp_3
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_0, in_1, in_2, in_3):
 return (in_0, in_1, in_2, in_3, 0)
def replacement_func():
 return kiln_generated
