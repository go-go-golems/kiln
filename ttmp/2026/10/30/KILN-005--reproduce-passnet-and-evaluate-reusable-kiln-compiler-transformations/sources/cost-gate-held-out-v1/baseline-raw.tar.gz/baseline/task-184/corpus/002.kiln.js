project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [1, 1024, 1, 1], "f16");
const v5 = N.expect(N.cast(N.sigmoid(N.cast(v4, "f32")), "f16"), [1, 1024, 1, 1], "f16");
const v6 = N.expect(N.mul(v3, v5), [1, 1024, 7, 7], "f16");
const v7 = N.expect(N.cast(N.gelu(N.cast(v6, "f32"), "none"), "f16"), [1, 1024, 7, 7], "f16");
const v8 = N.expect(N.adaptiveAvgPool2d(v7, [1, 1]), [1, 1024, 1, 1], "f16");
const v9 = N.expect(N.reshape(v8, [1, 1024]), [1, 1024], "f16");
const v10 = N.expect(v9, [1, 1024], "f16");
return {out0: v10};
}, {v0: k.tensor([1, 64, 1, 1], "f16"), v1: k.tensor([1024, 64, 1, 1], "f16"), v2: k.tensor([1024], "f16"), v3: k.tensor([1, 1024, 7, 7], "f16")});
