project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.cast(N.matmul(N.cast(v0, "f32"), N.cast(v1, "f32")), "bf16"), [24, 8, 256, 256], "bf16");
const v4 = N.expect(N.div(v3, 5.656854249492381), [24, 8, 256, 256], "bf16");
const v5 = N.expect(N.cast(N.softmax(N.cast(v4, "f32"), 3), "bf16"), [24, 8, 256, 256], "bf16");
const v6 = N.expect(v5, [24, 8, 256, 256], "bf16");
const v7 = N.expect(N.cast(N.matmul(N.cast(v6, "f32"), N.cast(v2, "f32")), "bf16"), [24, 8, 256, 32], "bf16");
const v8 = N.expect(N.transpose(v7, 1, 2), [24, 256, 8, 32], "bf16");
const v9 = N.expect(N.reshape(v8, [24, 256, 8, 32]), [24, 256, 8, 32], "bf16");
const v10 = N.expect(N.reshape(v9, [24, 256, 256]), [24, 256, 256], "bf16");
return {out0: v10};
}, {v0: k.tensor([24, 8, 256, 32], "bf16"), v1: k.tensor([24, 8, 32, 256], "bf16"), v2: k.tensor([24, 8, 256, 32], "bf16")});
