project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.cast(N.matmul(N.cast(v0, "f32"), N.cast(v1, "f32")), "f32"), [2, 5, 1024, 256], "f32");
const v4 = N.expect(N.div(v3, 8.0), [2, 5, 1024, 256], "f32");
const v5 = N.expect(N.cast(N.softmax(N.cast(v4, "f32"), 3), "f32"), [2, 5, 1024, 256], "f32");
const v6 = N.expect(v5, [2, 5, 1024, 256], "f32");
const v7 = N.expect(N.cast(N.matmul(N.cast(v6, "f32"), N.cast(v2, "f32")), "f32"), [2, 5, 1024, 64], "f32");
const v8 = N.expect(N.transpose(v7, 1, 2), [2, 1024, 5, 64], "f32");
const v9 = N.expect(N.reshape(v8, [2, 1024, 5, 64]), [2, 1024, 5, 64], "f32");
const v10 = N.expect(N.reshape(v9, [2, 1024, 320]), [2, 1024, 320], "f32");
return {out0: v10};
}, {v0: k.tensor([2, 5, 1024, 64], "f32"), v1: k.tensor([2, 5, 64, 256], "f32"), v2: k.tensor([2, 5, 256, 64], "f32")});
