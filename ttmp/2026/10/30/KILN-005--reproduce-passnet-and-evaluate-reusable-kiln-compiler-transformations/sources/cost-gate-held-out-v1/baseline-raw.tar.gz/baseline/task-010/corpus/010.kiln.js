project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [256, 1, 64, 48], "bf16");
const v4 = N.expect(N.reshape(v3, [256, 1, 3072]), [256, 1, 3072], "bf16");
const v5 = N.expect(N.cast(N.softmax(N.cast(v4, "f32"), 2), "bf16"), [256, 1, 3072], "bf16");
const v6 = N.expect(N.reshape(v5, [256, 1, 3072, 1]), [256, 1, 3072, 1], "bf16");
return {out0: v6};
}, {v0: k.tensor([256, 80, 64, 48], "bf16"), v1: k.tensor([1, 80, 1, 1], "bf16"), v2: k.tensor([1], "bf16")});
