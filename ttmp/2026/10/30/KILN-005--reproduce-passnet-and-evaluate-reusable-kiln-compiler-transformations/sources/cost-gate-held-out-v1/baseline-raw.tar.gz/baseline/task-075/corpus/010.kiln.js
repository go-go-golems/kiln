project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.cast(N.matmul(N.cast(v0, "f32"), N.cast(v1, "f32")), "f16"), [2, 1, 16384, 256], "f16");
const v4 = N.expect(N.div(v3, 8.0), [2, 1, 16384, 256], "f16");
const v5 = N.expect(N.cast(N.softmax(N.cast(v4, "f32"), 3), "f16"), [2, 1, 16384, 256], "f16");
const v6 = N.expect(v5, [2, 1, 16384, 256], "f16");
const v7 = N.expect(N.cast(N.matmul(N.cast(v6, "f32"), N.cast(v2, "f32")), "f16"), [2, 1, 16384, 64], "f16");
const v8 = N.expect(N.transpose(v7, 1, 2), [2, 16384, 1, 64], "f16");
const v9 = N.expect(N.reshape(v8, [2, 16384, 1, 64]), [2, 16384, 1, 64], "f16");
const v10 = N.expect(N.reshape(v9, [2, 16384, 64]), [2, 16384, 64], "f16");
return {out0: v10};
}, {v0: k.tensor([2, 1, 16384, 64], "f16"), v1: k.tensor([2, 1, 64, 256], "f16"), v2: k.tensor([2, 1, 256, 64], "f16")});
