from operator import iadd as kiln_iadd
import torch

def pattern(in_5, in_4, in_0, in_1, in_3, in_2, in_6):
    conv2d = torch.conv2d(in_5, in_4, None, (1, 1), (1, 1), (1, 1), 1)
    tmp_6 = torch.nn.functional.batch_norm(conv2d, in_0, in_1, in_3, in_2, False, 0.1, 1e-05)
    tmp_7 = torch.nn.functional.avg_pool2d(in_6, 2, 2, 0, True, False, None)
    return (tmp_7, tmp_6)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_5, in_4, in_0, in_1, in_3, in_2, in_6):
 return (in_5, in_4, in_0, in_1, in_3, in_2, in_6, 0)
def replacement_func():
 return kiln_generated
