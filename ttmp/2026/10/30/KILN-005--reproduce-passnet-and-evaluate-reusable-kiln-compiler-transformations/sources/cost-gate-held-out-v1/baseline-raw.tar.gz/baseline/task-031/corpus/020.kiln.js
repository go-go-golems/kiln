project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.cast(N.matmul(N.cast(v0, "f32"), N.cast(v1, "f32")), "f32"), [1, 8, 197, 40], "f32");
const v4 = N.expect(N.reshape(N.slice(v0, 2, 1, 197), [1, 8, 196, 40]), [1, 8, 196, 40], "f32");
const v5 = N.expect(N.reshape(N.slice(v2, 2, 1, 197), [1, 8, 196, 40]), [1, 8, 196, 40], "f32");
const v6 = N.expect(N.transpose(v5, 3, 2), [1, 8, 40, 196], "f32");
const v7 = N.expect(N.reshape(v6, [1, 320, 14, 14]), [1, 320, 14, 14], "f32");
const v8_0 = N.expect(N.slice(v7, 1, 0, 80), [1, 80, 14, 14], "f32");
const v8_1 = N.expect(N.slice(v7, 1, 80, 200), [1, 120, 14, 14], "f32");
const v8_2 = N.expect(N.slice(v7, 1, 200, 320), [1, 120, 14, 14], "f32");
const v9 = N.expect(v8_0, [1, 80, 14, 14], "f32");
const v10 = N.expect(v8_1, [1, 120, 14, 14], "f32");
const v11 = N.expect(v8_2, [1, 120, 14, 14], "f32");
return {out0: v3, out1: v9, out2: v10, out3: v11, out4: v4};
}, {v0: k.tensor([1, 8, 197, 40], "f32"), v1: k.tensor([1, 8, 40, 40], "f32"), v2: k.tensor([1, 8, 197, 40], "f32")});
