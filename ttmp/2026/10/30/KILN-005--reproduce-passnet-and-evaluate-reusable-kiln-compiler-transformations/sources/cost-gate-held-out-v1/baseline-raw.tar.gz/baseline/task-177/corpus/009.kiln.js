project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1}), [1, 400, 1, 1], "f16");
const v5 = N.expect(N.add(v4, 1.0), [1, 400, 1, 1], "f16");
const v6 = N.expect(N.div(v5, 2.0), [1, 400, 1, 1], "f16");
const v7 = N.expect(N.cast(N.select(N.gt(N.select(N.lt(N.cast(v6, "f32"), N.cast(N.cast(N.const(0.0, []), "f16"), "f32")), N.cast(N.cast(N.const(0.0, []), "f16"), "f32"), N.cast(v6, "f32")), N.cast(N.cast(N.const(1.0, []), "f16"), "f32")), N.cast(N.cast(N.const(1.0, []), "f16"), "f32"), N.select(N.lt(N.cast(v6, "f32"), N.cast(N.cast(N.const(0.0, []), "f16"), "f32")), N.cast(N.cast(N.const(0.0, []), "f16"), "f32"), N.cast(v6, "f32"))), "f16"), [1, 400, 1, 1], "f16");
const v8 = N.expect(N.mul(v3, v7), [1, 400, 16, 12], "f16");
return {out0: v8};
}, {v0: k.tensor([1, 100, 1, 1], "f16"), v1: k.tensor([400, 100, 1, 1], "f16"), v2: k.tensor([400], "f16"), v3: k.tensor([1, 400, 16, 12], "f16")});
