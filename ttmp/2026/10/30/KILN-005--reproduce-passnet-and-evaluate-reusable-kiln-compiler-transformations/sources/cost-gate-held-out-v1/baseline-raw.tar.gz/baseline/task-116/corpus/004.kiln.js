project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 4}), [1, 96, 1, 1], "bf16");
const v5 = N.expect(N.cast(N.sigmoid(N.cast(v4, "f32")), "bf16"), [1, 96, 1, 1], "bf16");
const v6 = N.expect(N.reshape(v5, [1, 96, 1, 1]), [1, 96, 1, 1], "bf16");
const v7 = N.expect(N.mul(v3, v6), [1, 96, 112, 112], "bf16");
const v8 = N.expect(N.reshape(v7, [1, 96, 112, 112]), [1, 96, 112, 112], "bf16");
return {out0: v8};
}, {v0: k.tensor([1, 32, 1, 1], "bf16"), v1: k.tensor([96, 8, 1, 1], "bf16"), v2: k.tensor([96], "bf16"), v3: k.tensor([1, 96, 112, 112], "bf16")});
