project("passnet").program(({v0, v1, v2}) => {
const v3 = N.expect(N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [1, 1], "dilation": [1, 1], "groups": 2048}), [4, 2048, 7, 7], "bf16");
const v4 = N.expect(N.cast(N.gelu(N.cast(v3, "f32"), "none"), "bf16"), [4, 2048, 7, 7], "bf16");
const v5 = N.expect(v4, [4, 2048, 7, 7], "bf16");
return {out0: v5};
}, {v0: k.tensor([4, 2048, 7, 7], "bf16"), v1: k.tensor([2048, 1, 3, 3], "bf16"), v2: k.tensor([2048], "bf16")});
