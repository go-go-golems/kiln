project("passnet").program(({v0, v1}) => {
const v2 = N.conv2d(v0, v1, null, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v3 = N.reshape(N.slice(v2, 1, 0, 256), [128, 256, 64, 64]);
return {out0: v2, out1: v3};
}, {v0: k.tensor([128, 128, 64, 64], "f16"), v1: k.tensor([296, 128, 1, 1], "f16")});
