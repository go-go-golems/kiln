const passnetProject = project("passnet").program(({v0, v1, v2, v3, v4, v5, v6, v7, v8, v9}) => {
const v10 = N.conv2d(v0, v1, null, {"stride": 1, "padding": 0, "dilation": 1, "groups": 512});
const v11 = N.reshape(v10, [1, 512, 64, 64]);
const v12 = N.cast(N.add(N.mul(N.div(N.sub(N.cast(v11, "f32"), N.reshape(N.cast(v2, "f32"), [1, 512, 1, 1])), N.sqrt(N.add(N.reshape(N.cast(v3, "f32"), [1, 512, 1, 1]), 1e-05))), N.reshape(N.cast(v4, "f32"), [1, 512, 1, 1])), N.reshape(N.cast(v5, "f32"), [1, 512, 1, 1])), "bf16");
const v13 = N.relu(v12);
const v14 = N.concat([v6, v7, v8, v9, v13], 1);
return {out0: v14};
}, {v0: k.tensor([1, 512, 70, 70], "bf16"), v1: k.tensor([512, 1, 7, 7], "bf16"), v2: k.tensor([512], "bf16"), v3: k.tensor([512], "bf16"), v4: k.tensor([512], "bf16"), v5: k.tensor([512], "bf16"), v6: k.tensor([1, 2048, 64, 64], "bf16"), v7: k.tensor([1, 512, 64, 64], "bf16"), v8: k.tensor([1, 512, 64, 64], "bf16"), v9: k.tensor([1, 512, 64, 64], "bf16")});
const passnetReferenceInputs = passnetProject.inputsFor(passnetProject.graph(), {names: ["v3"]});
for (let i=0; i<passnetReferenceInputs.v3.data.length; i++) passnetReferenceInputs.v3.data[i] = Math.abs(passnetReferenceInputs.v3.data[i]) + 0.1;
passnetProject.data(passnetReferenceInputs);
