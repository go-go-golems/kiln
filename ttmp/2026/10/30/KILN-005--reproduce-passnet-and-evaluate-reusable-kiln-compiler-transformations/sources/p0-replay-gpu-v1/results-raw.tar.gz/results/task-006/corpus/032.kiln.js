project("passnet").program(({v0, v1}) => {
const v2 = N.conv2d(v0, v1, null, {"stride": [2, 2], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v3 = N.reshape(N.slice(v2, 1, 0, 128), [1, 128, 48, 48]);
return {out0: v3, out1: v2};
}, {v0: k.tensor([1, 144, 96, 96], "f32"), v1: k.tensor([192, 144, 1, 1], "f32")});
