project("passnet").program(({v0, v1}) => {
const v2 = N.conv2d(v0, v1, null, {"stride": [2, 2], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v3 = N.reshape(N.slice(v2, 1, 0, 512), [32, 512, 28, 28]);
return {out0: v3, out1: v2};
}, {v0: k.tensor([32, 376, 56, 56], "f16"), v1: k.tensor([640, 376, 1, 1], "f16")});
