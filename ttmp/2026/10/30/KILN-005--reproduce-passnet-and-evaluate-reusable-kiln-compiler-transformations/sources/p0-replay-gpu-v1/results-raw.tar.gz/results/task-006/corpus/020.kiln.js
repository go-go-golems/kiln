project("passnet").program(({v0, v1}) => {
const v2 = N.conv2d(v0, v1, null, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v3 = N.reshape(N.slice(v2, 1, 0, 512), [1, 512, 48, 48]);
return {out0: v3, out1: v2};
}, {v0: k.tensor([1, 400, 48, 48], "f16"), v1: k.tensor([576, 400, 1, 1], "f16")});
