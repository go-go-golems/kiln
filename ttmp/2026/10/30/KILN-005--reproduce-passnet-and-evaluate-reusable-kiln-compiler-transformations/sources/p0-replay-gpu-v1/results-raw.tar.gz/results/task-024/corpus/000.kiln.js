project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.add(v0, v1);
const v5 = N.cast(N.reshape(N.layer_norm(N.reshape(N.cast(v4, "f32"), [249, 1024]), N.reshape(N.cast(v2, "f32"), [1024]), N.reshape(N.cast(v3, "f32"), [1024]), {"eps": 1e-05}), [1, 249, 1024]), "f16");
return {out0: v4, out1: v5};
}, {v0: k.tensor([1, 249, 1024], "f16"), v1: k.tensor([1, 249, 1024], "f16"), v2: k.tensor([1024], "f16"), v3: k.tensor([1024], "f16")});
