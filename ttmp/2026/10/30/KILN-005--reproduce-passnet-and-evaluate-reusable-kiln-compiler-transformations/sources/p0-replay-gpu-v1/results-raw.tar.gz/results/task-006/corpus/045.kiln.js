project("passnet").program(({v0, v1}) => {
const v2 = N.conv2d(v0, v1, null, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v3 = N.reshape(N.slice(v2, 1, 0, 128), [128, 128, 32, 32]);
return {out0: v3, out1: v2};
}, {v0: k.tensor([128, 256, 32, 32], "f16"), v1: k.tensor([160, 256, 1, 1], "f16")});
