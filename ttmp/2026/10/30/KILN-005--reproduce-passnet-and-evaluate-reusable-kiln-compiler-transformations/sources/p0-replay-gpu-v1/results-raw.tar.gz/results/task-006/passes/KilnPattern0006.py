from operator import iadd as kiln_iadd
import torch

def pattern(in_1, in_0):
    conv2d = torch.conv2d(in_1, in_0, None, (2, 2), (0, 0), (1, 1), 1)
    tmp_2 = conv2d[slice(None, None, None), slice(None, 512, None), slice(None, None, None), slice(None, None, None)]
    return (tmp_2, conv2d)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_1, in_0):
 return (in_1, in_0, 6)
def replacement_func():
 return kiln_generated
