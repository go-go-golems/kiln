project("passnet").program(({v0, v1}) => {
const v2 = N.conv2d(v0, v1, null, {"stride": [2, 2], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v3 = N.reshape(N.slice(v2, 1, 0, 2048), [128, 2048, 8, 8]);
return {out0: v3, out1: v2};
}, {v0: k.tensor([128, 2432, 16, 16], "f16"), v1: k.tensor([2304, 2432, 1, 1], "f16")});
