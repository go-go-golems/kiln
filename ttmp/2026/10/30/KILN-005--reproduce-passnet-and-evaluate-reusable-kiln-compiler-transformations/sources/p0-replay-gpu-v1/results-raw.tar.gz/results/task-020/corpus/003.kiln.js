project("passnet").program(({v0, v1, v2, v3, v4, v5}) => {
const v6 = N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v7 = N.resizeBilinear(v3, [64, 64]);
const v8 = N.cast(N.sigmoid(N.cast(v7, "f32")), "f16");
const v9 = N.mul(v4, v8);
const v10 = N.cast(N.sigmoid(N.cast(v6, "f32")), "f16");
const v11 = N.mul(v5, v10);
const v12 = N.resizeBilinear(v11, [64, 64]);
const v13 = N.add(v9, v12);
return {out0: v13};
}, {v0: k.tensor([2, 128, 16, 16], "f16"), v1: k.tensor([128, 128, 1, 1], "f16"), v2: k.tensor([128], "f16"), v3: k.tensor([2, 128, 16, 16], "f16"), v4: k.tensor([2, 128, 64, 64], "f16"), v5: k.tensor([2, 128, 16, 16], "f16")});
