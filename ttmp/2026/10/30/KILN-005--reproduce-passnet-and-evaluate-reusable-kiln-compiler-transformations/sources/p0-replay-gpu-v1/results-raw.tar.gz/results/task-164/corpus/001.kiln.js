project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.cast(N.matmul(N.cast(v0, "f32"), N.cast(v1, "f32")), "bf16");
const v5 = v2;
const v6 = v3;
return {out0: v6, out1: v5, out2: v4};
}, {v0: k.tensor([2, 768], "bf16"), v1: k.tensor([768, 1], "bf16"), v2: k.tensor([1], "bf16"), v3: k.tensor([1], "bf16")});
