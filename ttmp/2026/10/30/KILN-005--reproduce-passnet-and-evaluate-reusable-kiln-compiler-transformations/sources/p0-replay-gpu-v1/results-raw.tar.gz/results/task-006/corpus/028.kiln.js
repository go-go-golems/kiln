project("passnet").program(({v0, v1}) => {
const v2 = N.conv2d(v0, v1, null, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v3 = N.reshape(N.slice(v2, 1, 0, 64), [128, 64, 56, 56]);
return {out0: v2, out1: v3};
}, {v0: k.tensor([128, 10, 56, 56], "f32"), v1: k.tensor([96, 10, 1, 1], "f32")});
