project("passnet").program(({v0, v1, v2}) => {
const v3 = N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v4 = N.transpose(N.transpose(v3, 1, 2), 2, 3);
const v5 = N.reshape(v4, [32, 8192, 1]);
const v6 = N.cast(N.sigmoid(N.cast(v5, "f32")), "f32");
return {out0: v6};
}, {v0: k.tensor([32, 512, 64, 128], "f32"), v1: k.tensor([1, 512, 1, 1], "f32"), v2: k.tensor([1], "f32")});
