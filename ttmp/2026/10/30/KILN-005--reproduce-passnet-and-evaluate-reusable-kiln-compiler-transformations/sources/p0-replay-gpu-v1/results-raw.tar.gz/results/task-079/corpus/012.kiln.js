project("passnet").program(({v0, v1, v2}) => {
const v3 = N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v4 = N.transpose(N.transpose(v3, 1, 2), 2, 3);
const v5 = N.reshape(v4, [6, 8192, 4]);
const v6 = N.cast(N.sigmoid(N.cast(v5, "f32")), "f16");
return {out0: v6};
}, {v0: k.tensor([6, 512, 64, 128], "f16"), v1: k.tensor([4, 512, 1, 1], "f16"), v2: k.tensor([4], "f16")});
