from operator import iadd as kiln_iadd
import torch

def pattern(in_9, in_4, in_0, in_1, in_3, in_2, in_5, in_7, in_8, in_6):
    conv2d = torch.conv2d(input=in_9, weight=in_4, groups=512)
    tmp_5 = conv2d.view(1, 512, 64, 64)
    tmp_6 = torch.nn.functional.batch_norm(tmp_5, in_0, in_1, in_3, in_2, False, 0.1, 1e-05)
    tmp_7 = torch.nn.functional.relu(tmp_6, inplace=False)
    tmp_8 = torch.cat([in_5, in_7, in_8, in_6, tmp_7], dim=1)
    return tmp_8
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_9, in_4, in_0, in_1, in_3, in_2, in_5, in_7, in_8, in_6):
 return (in_9, in_4, in_0, in_1, in_3, in_2, in_5, in_7, in_8, in_6, 0)
def replacement_func():
 return kiln_generated
