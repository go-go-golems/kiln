project("passnet").program(({v0, v1}) => {
const v2 = N.conv2d(v0, v1, null, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v3 = N.reshape(N.slice(v2, 1, 0, 256), [32, 256, 56, 56]);
return {out0: v3, out1: v2};
}, {v0: k.tensor([32, 200, 56, 56], "f16"), v1: k.tensor([276, 200, 1, 1], "f16")});
