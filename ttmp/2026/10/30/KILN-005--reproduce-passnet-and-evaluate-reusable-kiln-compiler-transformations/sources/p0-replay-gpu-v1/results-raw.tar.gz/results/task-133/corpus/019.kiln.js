project("passnet").program(({v0, v1, v2, v3, v4}) => {
const v5 = N.conv2d(v0, v1, v2, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v6 = N.cast(N.reshape(N.layer_norm(N.reshape(N.cast(v5, "f32"), [64, 38]), N.reshape(N.cast(v3, "f32"), [38]), N.reshape(N.cast(v4, "f32"), [38]), {"eps": 1e-05}), [64, 38, 1, 1]), "bf16");
const v7 = N.relu(v6);
return {out0: v7};
}, {v0: k.tensor([64, 608, 1, 1], "bf16"), v1: k.tensor([38, 608, 1, 1], "bf16"), v2: k.tensor([38], "bf16"), v3: k.tensor([38, 1, 1], "bf16"), v4: k.tensor([38, 1, 1], "bf16")});
