from operator import iadd as kiln_iadd
import torch

def pattern(in_2, in_3, in_1, in_0):
    tmp_2 = in_2 + in_3
    tmp_4 = torch.nn.functional.layer_norm(tmp_2, (1024,), in_1, in_0, 1e-05)
    return (tmp_2, tmp_4)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_2, in_3, in_1, in_0):
 return (in_2, in_3, in_1, in_0, 0)
def replacement_func():
 return kiln_generated
