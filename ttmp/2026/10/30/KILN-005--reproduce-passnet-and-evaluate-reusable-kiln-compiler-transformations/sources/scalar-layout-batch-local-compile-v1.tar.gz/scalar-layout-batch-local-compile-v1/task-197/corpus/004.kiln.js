project("passnet").program(({v0, v1, v2}) => {
const v3 = N.cast(N.sigmoid(N.cast(v2, "f32")), "f32");
const v4 = N.reshape(v3, [1, 2048, 1, 1]);
const v5 = N.expand(v4, [1, 2048, 6, 6]);
const v6 = N.mul(v1, v5);
const v7 = N.add(v6, v0);
const v8 = N.relu(v7);
const v9 = N.adaptiveAvgPool2d(v8, [1, 1]);
const v10 = N.reshape(v9, [1, 2048]);
return {out0: v10};
}, {v0: k.tensor([1, 2048, 6, 6], "f32"), v1: k.tensor([1, 2048, 6, 6], "f32"), v2: k.tensor([1, 1, 2048], "f32")});
