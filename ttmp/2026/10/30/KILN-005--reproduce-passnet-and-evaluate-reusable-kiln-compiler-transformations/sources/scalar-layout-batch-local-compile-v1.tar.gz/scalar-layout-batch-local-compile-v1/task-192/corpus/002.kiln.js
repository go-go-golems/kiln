project("passnet").program(({v0, v1, v2}) => {
const v3 = N.conv2d(v2, v1, v0, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v4 = N.cast(N.mul(N.cast(v3, "f32"), N.div(N.select(N.lt(N.cast(v3, "f32"), -3), 0, N.select(N.gt(N.cast(v3, "f32"), 3), 6, N.add(N.cast(v3, "f32"), 3))), 6)), "f32");
const v5 = N.reshape(v4, [32, 1280]);
return {out0: v5};
}, {v0: k.tensor([1280], "f32"), v1: k.tensor([1280, 960, 1, 1], "f32"), v2: k.tensor([32, 960, 1, 1], "f32")});
