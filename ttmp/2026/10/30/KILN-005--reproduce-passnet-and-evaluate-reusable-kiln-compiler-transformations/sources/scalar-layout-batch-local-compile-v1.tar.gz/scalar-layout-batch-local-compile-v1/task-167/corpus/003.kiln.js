project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.conv2d(v3, v1, v0, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v5 = N.cast(N.select(N.lt(N.cast(v4, "f32"), -3), 0, N.select(N.gt(N.cast(v4, "f32"), 3), 1, N.add(N.div(N.cast(v4, "f32"), 6), 0.5))), "bf16");
const v6 = N.mul(v2, v5);
const v7 = N.adaptiveAvgPool2d(v6, [1, 1]);
const v8 = N.reshape(v7, [1, 1024]);
const v9 = v8;
return {out0: v9};
}, {v0: k.tensor([1024], "bf16"), v1: k.tensor([1024, 1024, 1, 1], "bf16"), v2: k.tensor([1, 1024, 12, 12], "bf16"), v3: k.tensor([1, 1024, 1, 1], "bf16")});
