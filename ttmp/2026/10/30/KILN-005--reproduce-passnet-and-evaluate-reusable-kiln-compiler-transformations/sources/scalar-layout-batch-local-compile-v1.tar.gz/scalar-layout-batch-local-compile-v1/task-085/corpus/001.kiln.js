project("passnet").program(({v0}) => {
const v1 = N.div(v0, 11.313708498984761);
const v2 = N.relu(v1);
const v3 = N.cast(N.square(N.cast(v2, "f32")), "f16");
return {out0: v3};
}, {v0: k.tensor([8, 17, 17], "f16")});
