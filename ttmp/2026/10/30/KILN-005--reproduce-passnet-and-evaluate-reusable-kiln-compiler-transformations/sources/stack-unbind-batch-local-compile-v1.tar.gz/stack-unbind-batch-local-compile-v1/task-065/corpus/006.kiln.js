project("passnet").program(({v0, v1, v2}) => {
const v3 = N.mul(v2, v1);
const v4 = N.add(v3, v0);
const v5_0 = N.reshape(N.slice(v4, 2, 0, 1), [512, 17, 128]);
const v5_1 = N.reshape(N.slice(v4, 2, 1, 2), [512, 17, 128]);
const v6 = v5_0;
const v7 = v5_1;
const v8 = N.transpose(v7, 1, 2);
return {out0: v8, out1: v6};
}, {v0: k.tensor([2, 128], "bf16"), v1: k.tensor([1, 1, 2, 128], "bf16"), v2: k.tensor([512, 17, 1, 128], "bf16")});
