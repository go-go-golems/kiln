project("passnet").program(({v0, v1, v2, v3}) => {
const v4 = N.conv2d(v2, v1, v0, {"stride": [1, 1], "padding": [0, 0], "dilation": [1, 1], "groups": 1});
const v5 = N.reshape(v4, [1, 16, 512, 64, 128]);
const v6 = N.cast(N.reshape(N.sum(N.cast(v5, "f32"), 0, true), [16, 512, 64, 128]), "f32");
const v7 = N.concat([v6, v3], 1);
return {out0: v7};
}, {v0: k.tensor([512], "f32"), v1: k.tensor([512, 256, 1, 1], "f32"), v2: k.tensor([16, 256, 64, 128], "f32"), v3: k.tensor([16, 512, 64, 128], "f32")});
