project("passnet").program(({v0, v1}) => {
const v2 = N.cast(N.linear(N.cast(v1, "f32"), N.cast(v0, "f32"), null), "f16");
const v3 = N.reshape(v2, [1, 197, 3, 16, 48]);
const v4 = N.transpose(N.transpose(N.transpose(v3, 0, 2), 1, 2), 2, 3);
const v5_0 = N.reshape(N.slice(v4, 0, 0, 1), [1, 16, 197, 48]);
const v5_1 = N.reshape(N.slice(v4, 0, 1, 2), [1, 16, 197, 48]);
const v5_2 = N.reshape(N.slice(v4, 0, 2, 3), [1, 16, 197, 48]);
const v6 = v5_0;
const v7 = v5_1;
const v8 = v5_2;
const v9 = N.transpose(v7, 2, 3);
return {out0: v6, out1: v9, out2: v8};
}, {v0: k.tensor([2304, 768], "f16"), v1: k.tensor([1, 197, 768], "f16")});
