from operator import iadd as kiln_iadd
import torch

def pattern(in_3, in_2, in_1, in_0):
    tmp_2 = in_3.contiguous()
    in_3 = None
    tmp_3 = tmp_2.view(-1, 35, 35, 384)
    tmp_2 = None
    tmp_4 = torch.roll(tmp_3, shifts=(3, 3), dims=(1, 2))
    tmp_3 = None
    tmp_5 = tmp_4[slice(None, None, None), slice(None, 32, None), slice(None, 32, None), slice(None, None, None)]
    tmp_4 = None
    tmp_6 = tmp_5.contiguous()
    tmp_5 = None
    tmp_7 = tmp_6.view(1, 1024, 384)
    tmp_6 = None
    tmp_8 = in_2 + tmp_7
    in_2 = tmp_7 = None
    tmp_9 = torch.nn.functional.layer_norm(tmp_8, (384,), in_1, in_0, 1e-05)
    in_1 = in_0 = None
    return (tmp_8, tmp_9)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_3, in_2, in_1, in_0):
 return (in_3, in_2, in_1, in_0, 0)
def replacement_func():
 return kiln_generated
