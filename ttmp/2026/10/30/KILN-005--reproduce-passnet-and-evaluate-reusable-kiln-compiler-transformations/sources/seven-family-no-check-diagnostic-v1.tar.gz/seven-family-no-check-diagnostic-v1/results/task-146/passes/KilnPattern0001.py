from operator import iadd as kiln_iadd
import torch

def pattern(in_1, in_3, in_2, in_0, in_4):
    matmul = in_1 @ in_3
    in_1 = in_3 = None
    tmp_1 = matmul.reshape(-1, 8, 15)
    matmul = None
    tmp_2 = torch.nn.functional.pad(tmp_1, [0, 1], 'constant', None)
    tmp_1 = None
    tmp_3 = tmp_2.flatten(1)
    tmp_2 = None
    tmp_4 = torch.nn.functional.pad(tmp_3, [0, 7], 'constant', None)
    tmp_3 = None
    tmp_5 = tmp_4.reshape(-1, 9, 15)
    tmp_4 = None
    tmp_6 = tmp_5[slice(None, None, None), slice(None, 8, None), slice(7, None, None)]
    tmp_5 = None
    tmp_7 = tmp_6.reshape(4, 8, 1, 8, 8)
    tmp_6 = None
    tmp_8 = tmp_7.expand(-1, -1, 8, -1, -1)
    tmp_7 = None
    tmp_9 = tmp_8.permute((0, 3, 1, 4, 2))
    tmp_8 = None
    tmp_10 = tmp_9 + in_2
    tmp_9 = in_2 = None
    tmp_11 = tmp_10.reshape(4, 64, 64)
    tmp_10 = None
    tmp_12 = in_0 + tmp_11
    in_0 = tmp_11 = None
    tmp_13 = tmp_12.softmax(dim=-1)
    tmp_12 = None
    matmul_1 = tmp_13 @ in_4
    tmp_13 = in_4 = None
    tmp_15 = matmul_1.transpose(-1, -2)
    matmul_1 = None
    return tmp_15
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_1, in_3, in_2, in_0, in_4):
 return (in_1, in_3, in_2, in_0, in_4, 1)
def replacement_func():
 return kiln_generated
