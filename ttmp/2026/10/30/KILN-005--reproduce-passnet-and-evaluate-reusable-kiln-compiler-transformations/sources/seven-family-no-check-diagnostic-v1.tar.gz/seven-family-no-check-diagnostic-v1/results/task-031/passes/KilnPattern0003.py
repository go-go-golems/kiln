from operator import iadd as kiln_iadd
import torch

def pattern(in_1, in_0, in_2):
    matmul = in_1 @ in_0
    in_0 = None
    tmp_1 = in_1[slice(None, None, None), slice(None, None, None), slice(1, None, None), slice(None, None, None)]
    in_1 = None
    tmp_2 = in_2[slice(None, None, None), slice(None, None, None), slice(1, None, None), slice(None, None, None)]
    in_2 = None
    tmp_3 = tmp_2.transpose(-1, -2)
    tmp_2 = None
    tmp_4 = tmp_3.reshape(1, 256, 48, 48)
    tmp_3 = None
    split = torch.functional.split(tmp_4, [64, 96, 96], dim=1)
    tmp_4 = None
    tmp_6 = split[0]
    tmp_7 = split[1]
    tmp_8 = split[2]
    split = None
    return (matmul, tmp_6, tmp_7, tmp_8, tmp_1)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_1, in_0, in_2):
 return (in_1, in_0, in_2, 3)
def replacement_func():
 return kiln_generated
