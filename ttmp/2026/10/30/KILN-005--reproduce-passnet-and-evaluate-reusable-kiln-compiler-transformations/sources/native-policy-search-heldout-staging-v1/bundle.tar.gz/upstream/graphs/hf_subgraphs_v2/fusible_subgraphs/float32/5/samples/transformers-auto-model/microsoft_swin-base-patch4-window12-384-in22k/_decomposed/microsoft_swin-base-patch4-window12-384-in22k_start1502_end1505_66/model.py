import torch

class GraphModule(torch.nn.Module):

    def forward(self, in_0, in_1, in_2, in_3):
        tmp_0 = in_0
        tmp_1 = in_1
        tmp_2 = in_2 + in_3
        tmp_3 = torch.nn.functional.layer_norm(tmp_2, (1024,), tmp_1, tmp_0, 1e-05)
        tmp_2 = tmp_1 = tmp_0 = None
        tmp_4 = tmp_3.transpose(1, 2)
        return (tmp_3, tmp_4)