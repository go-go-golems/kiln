project("passnet").program(({v0, v1, v2, v3, v4}) => {
const v5 = N.cast(N.linear(N.cast(v0, "f32"), N.cast(v2, "f32"), N.cast(v1, "f32")), "f32");
const v6 = N.reshape(v4, [1, 15, 4, 4]);
const v7 = N.transpose(v6, 1, 2);
const v8 = N.reshape(v5, [1, 15, 4, 4]);
const v9 = N.transpose(v8, 1, 2);
const v10 = N.reshape(v3, [1, 1, 15, 15]);
return {out0: v10, out1: v7, out2: v9};
}, {v0: k.tensor([1, 15, 16], "f32"), v1: k.tensor([16], "f32"), v2: k.tensor([16, 16], "f32"), v3: k.tensor([1, 1, 15, 15], "f32"), v4: k.tensor([1, 15, 16], "f32")});
