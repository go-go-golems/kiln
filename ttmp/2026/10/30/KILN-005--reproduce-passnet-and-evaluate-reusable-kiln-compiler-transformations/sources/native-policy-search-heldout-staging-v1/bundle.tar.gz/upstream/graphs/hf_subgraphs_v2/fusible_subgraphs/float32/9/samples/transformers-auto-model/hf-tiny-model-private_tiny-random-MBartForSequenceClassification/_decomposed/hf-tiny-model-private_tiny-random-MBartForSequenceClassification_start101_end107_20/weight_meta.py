class Program_weight_tensor_meta_L_encoder_hidden_states_:
	name = "in_0"
	original_name = "L_encoder_hidden_states_"
	shape = [1, 15, 16]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.000
	std = 1.002


class Program_weight_tensor_meta_L_self_modules_layers_modules_1_modules_encoder_attn_modules_v_proj_parameters_bias_:
	name = "in_1"
	original_name = "L_self_modules_layers_modules_1_modules_encoder_attn_modules_v_proj_parameters_bias_"
	shape = [16]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.000
	std = 0.000
	data = [0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000]


class Program_weight_tensor_meta_L_self_modules_layers_modules_1_modules_encoder_attn_modules_v_proj_parameters_weight_:
	name = "in_2"
	original_name = "L_self_modules_layers_modules_1_modules_encoder_attn_modules_v_proj_parameters_weight_"
	shape = [16, 16]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = -0.000
	std = 0.021


class Program_weight_tensor_meta_encoder_attention_mask:
	name = "in_3"
	original_name = "encoder_attention_mask"
	shape = [1, 1, 15, 15]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.000
	std = 0.100


class Program_weight_tensor_meta_key_states_6:
	name = "in_4"
	original_name = "key_states_6"
	shape = [1, 15, 16]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = -0.000
	std = 0.003
