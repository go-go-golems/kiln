class Program_weight_tensor_meta_L_self_modules_encoder_modules_layer_modules_10_modules_layernorm_before_parameters_bias_:
	name = "in_0"
	original_name = "L_self_modules_encoder_modules_layer_modules_10_modules_layernorm_before_parameters_bias_"
	shape = [192]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_encoder_modules_layer_modules_10_modules_layernorm_before_parameters_weight_:
	name = "in_1"
	original_name = "L_self_modules_encoder_modules_layer_modules_10_modules_layernorm_before_parameters_weight_"
	shape = [192]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 1.000
	std = 0.000


class Program_weight_tensor_meta_hidden_states_74:
	name = "in_2"
	original_name = "hidden_states_74"
	shape = [1, 198, 192]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = -0.022
	std = 0.201


class Program_weight_tensor_meta_hidden_states_78:
	name = "in_3"
	original_name = "hidden_states_78"
	shape = [1, 198, 192]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.000
	std = 0.003
