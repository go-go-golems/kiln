class Program_weight_tensor_meta_L_self_modules_layernorm_parameters_bias_:
	name = "in_0"
	original_name = "L_self_modules_layernorm_parameters_bias_"
	shape = [768]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_L_self_modules_layernorm_parameters_weight_:
	name = "in_1"
	original_name = "L_self_modules_layernorm_parameters_weight_"
	shape = [768]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 1.000
	std = 0.000


class Program_weight_tensor_meta_hidden_states_90:
	name = "in_2"
	original_name = "hidden_states_90"
	shape = [1, 197, 768]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.013
	std = 0.235


class Program_weight_tensor_meta_hidden_states_94:
	name = "in_3"
	original_name = "hidden_states_94"
	shape = [1, 197, 768]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = -0.000
	std = 0.014
