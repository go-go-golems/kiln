class Program_weight_tensor_meta_L_self_modules_model_modules_decoder_modules_layers_modules_0_modules_encoder_attn_modules_v_proj_parameters_bias_:
	name = "in_0"
	original_name = "L_self_modules_model_modules_decoder_modules_layers_modules_0_modules_encoder_attn_modules_v_proj_parameters_bias_"
	shape = [512]
	dtype = "torch.float32"
	device = "cpu"
	mean = 0.001
	std = 0.021


class Program_weight_tensor_meta_L_self_modules_model_modules_decoder_modules_layers_modules_0_modules_encoder_attn_modules_v_proj_parameters_weight_:
	name = "in_1"
	original_name = "L_self_modules_model_modules_decoder_modules_layers_modules_0_modules_encoder_attn_modules_v_proj_parameters_weight_"
	shape = [512, 512]
	dtype = "torch.float32"
	device = "cpu"
	mean = -0.000
	std = 0.049


class Program_weight_tensor_meta_encoder_attention_mask:
	name = "in_2"
	original_name = "encoder_attention_mask"
	shape = [1, 1, 1, 37]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.000
	std = 0.000
	data = [0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000]


class Program_weight_tensor_meta_hidden_states_55:
	name = "in_3"
	original_name = "hidden_states_55"
	shape = [1, 37, 512]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.007
	std = 0.461


class Program_weight_tensor_meta_key_states_14:
	name = "in_4"
	original_name = "key_states_14"
	shape = [1, 37, 512]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.002
	std = 0.124


class Program_weight_tensor_meta_query_states_7:
	name = "in_5"
	original_name = "query_states_7"
	shape = [1, 8, 1, 64]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.008
	std = 0.284
