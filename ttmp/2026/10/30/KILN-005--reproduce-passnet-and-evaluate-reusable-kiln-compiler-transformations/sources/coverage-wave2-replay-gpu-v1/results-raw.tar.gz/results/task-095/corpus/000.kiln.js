project("passnet").program(({v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11}) => {
const v12 = N.expect(N.cast(N.linear(N.cast(v0, "f32"), N.cast(v1, "f32"), N.cast(v2, "f32")), "f16"), [300, 1, 256], "f16");
const v13 = N.expect(N.cast(N.reshape(N.layer_norm(N.reshape(N.cast(v12, "f32"), [300, 256]), N.reshape(N.cast(v3, "f32"), [256]), N.reshape(N.cast(v4, "f32"), [256]), {"eps": 1e-05}), [300, 1, 256]), "f16"), [300, 1, 256], "f16");
const v14 = N.expect(N.cast(N.sigmoid(N.cast(v5, "f32")), "f16"), [300, 1, 256], "f16");
const v15 = N.expect(N.cast(N.sigmoid(N.cast(v13, "f32")), "f16"), [300, 1, 256], "f16");
const v16 = N.expect(N.cast(N.reshape(N.layer_norm(N.reshape(N.cast(v6, "f32"), [300, 256]), N.reshape(N.cast(v7, "f32"), [256]), N.reshape(N.cast(v8, "f32"), [256]), {"eps": 1e-05}), [300, 256]), "f16"), [300, 256], "f16");
const v17 = N.expect(N.cast(N.reshape(N.layer_norm(N.reshape(N.cast(v9, "f32"), [300, 256]), N.reshape(N.cast(v10, "f32"), [256]), N.reshape(N.cast(v11, "f32"), [256]), {"eps": 1e-05}), [300, 1, 256]), "f16"), [300, 1, 256], "f16");
const v18 = N.expect(N.reshape(v16, [300, 1, 256]), [300, 1, 256], "f16");
const v19 = N.expect(N.mul(v15, v18), [300, 1, 256], "f16");
const v20 = N.expect(N.mul(v14, v17), [300, 1, 256], "f16");
const v21 = N.expect(N.add(v19, v20), [300, 1, 256], "f16");
return {out0: v21};
}, {v0: k.tensor([300, 1, 256], "f16"), v1: k.tensor([256, 256], "f16"), v2: k.tensor([256], "f16"), v3: k.tensor([256], "f16"), v4: k.tensor([256], "f16"), v5: k.tensor([300, 1, 256], "f16"), v6: k.tensor([300, 256], "f16"), v7: k.tensor([256], "f16"), v8: k.tensor([256], "f16"), v9: k.tensor([300, 1, 256], "f16"), v10: k.tensor([256], "f16"), v11: k.tensor([256], "f16")});
