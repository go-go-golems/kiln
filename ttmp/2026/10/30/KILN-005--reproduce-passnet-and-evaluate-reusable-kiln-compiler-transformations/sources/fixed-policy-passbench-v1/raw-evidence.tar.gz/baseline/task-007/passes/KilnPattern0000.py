from operator import iadd as kiln_iadd
import torch

def pattern(in_3, in_1, in_0, in_4, in_2, in_5):
    linear = torch.nn.functional.linear(in_3, in_1, in_0)
    in_3 = in_1 = in_0 = None
    tmp_3 = in_4.view(1, 1, -1, 64)
    in_4 = None
    tmp_4 = tmp_3.transpose(1, 2)
    tmp_3 = None
    tmp_5 = linear.view(1, 1, -1, 64)
    linear = None
    tmp_6 = tmp_5.transpose(1, 2)
    tmp_5 = None
    tmp_7 = in_2[slice(None, None, None), slice(None, None, None), slice(None, None, None), slice(None, 1, None)]
    in_2 = None
    tmp_8 = in_5.contiguous()
    in_5 = None
    tmp_9 = tmp_4.contiguous()
    tmp_4 = None
    tmp_10 = tmp_6.contiguous()
    tmp_6 = None
    return (tmp_7, tmp_9, tmp_8, tmp_10)
from _kiln_generated_runtime import kiln_generated
def replacement_args(in_3, in_1, in_0, in_4, in_2, in_5):
 return (in_3, in_1, in_0, in_4, in_2, in_5, 0)
def replacement_func():
 return kiln_generated
