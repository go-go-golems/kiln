// The frontend ("Torch IR", dialect nn) and the canonical primitive set ("Tensor IR", dialect tensor),
// with reference semantics for both and the decomposition and optimization passes between them.
import { k, P, Value, KilnError, Node } from "../core/kiln.js";
import { Tensor, numel, strides, rng } from "../core/util.js";
import * as IX from "../core/ix.js";
import { fn as F, reducer } from "./fns.js";

// ----------------------------------------------------------------------------- reference helpers
const asT = (x) => (x instanceof Tensor ? x : typeof x === "number" ? new Tensor([], Float32Array.of(x)) : Array.isArray(x) ? new Tensor([x.length], Float32Array.from(x)) : x);
export function bshape(...shapes) {
  const n = Math.max(...shapes.map((s) => s.length));
  const out = [];
  for (let i = 0; i < n; i++) {
    let d = 1;
    for (const s of shapes) {
      const x = s[s.length - n + i] ?? 1;
      if (x !== 1 && d !== 1 && x !== d) throw new KilnError("ShapeError", `cannot broadcast shapes ${shapes.map((q) => "(" + q.join(",") + ")").join(" and ")}`);
      if (x !== 1) d = x;
    }
    out.push(d);
  }
  return out;
}
function ewRef(name, xs) {
  xs = xs.map(asT);
  const f = F(name).js;
  const shape = bshape(...xs.map((x) => x.shape));
  const out = new Tensor(shape);
  const n = out.data.length, D = shape.length, m = xs.length, o = out.data;
  // per input, per output dim: the stride to step (0 where the input broadcasts)
  const st = xs.map((x) => { const s = strides(x.shape); const off = D - x.shape.length; return shape.map((d, i) => (i < off || x.shape[i - off] === 1 ? 0 : s[i - off])); });
  const d0 = xs[0].data, d1 = xs[1]?.data, d2 = xs[2]?.data;
  // fast path: inputs are full-size or scalars
  if (xs.every((x) => x.data.length === n || x.data.length === 1)) {
    const at = (d) => (d.length === 1 && n !== 1 ? 0 : 1);
    const s0 = at(d0), s1 = d1 ? at(d1) : 0, s2 = d2 ? at(d2) : 0;
    // the common arithmetic without a call per element
    if (m === 2 && (name === "add" || name === "sub" || name === "mul" || name === "div")) {
      if (name === "add") for (let e = 0; e < n; e++) o[e] = d0[e * s0] + d1[e * s1];
      else if (name === "sub") for (let e = 0; e < n; e++) o[e] = d0[e * s0] - d1[e * s1];
      else if (name === "mul") for (let e = 0; e < n; e++) o[e] = d0[e * s0] * d1[e * s1];
      else for (let e = 0; e < n; e++) o[e] = d0[e * s0] / d1[e * s1];
      return out;
    }
    if (m === 3 && name === "fma") { for (let e = 0; e < n; e++) o[e] = d0[e * s0] * d1[e * s1] + d2[e * s2]; return out; }
    if (m === 1) for (let e = 0; e < n; e++) o[e] = f(d0[e * s0]);
    else if (m === 2) for (let e = 0; e < n; e++) o[e] = f(d0[e * s0], d1[e * s1]);
    else if (m === 3) for (let e = 0; e < n; e++) o[e] = f(d0[e * s0], d1[e * s1], d2[e * s2]);
    else for (let e = 0; e < n; e++) o[e] = f(...xs.map((x) => x.data[x.data.length === 1 ? 0 : e]));
    return out;
  }
  // general broadcasting: an odometer over the output with running input offsets
  const idx = new Int32Array(D), off = new Array(m).fill(0);
  for (let e = 0; e < n; e++) {
    o[e] = m === 1 ? f(d0[off[0]]) : m === 2 ? f(d0[off[0]], d1[off[1]]) : m === 3 ? f(d0[off[0]], d1[off[1]], d2[off[2]]) : f(...xs.map((x, j) => x.data[off[j]]));
    for (let i = D - 1; i >= 0; i--) {
      idx[i]++;
      for (let j = 0; j < m; j++) off[j] += st[j][i];
      if (idx[i] < shape[i]) break;
      for (let j = 0; j < m; j++) off[j] -= st[j][i] * shape[i];
      idx[i] = 0;
    }
  }
  return out;
}
function reduceRef(name, x, axis, keep = true) {
  x = asT(x);
  axis = axis < 0 ? x.shape.length + axis : axis;
  const R = reducer(name);
  const oshape = x.shape.map((d, i) => (i === axis ? 1 : d));
  const out = new Tensor(oshape);
  const st = strides(x.shape), os = strides(oshape);
  for (let e = 0; e < out.data.length; e++) {
    let r = e, base = 0;
    for (let i = 0; i < oshape.length; i++) { const c = Math.floor(r / os[i]); r -= c * os[i]; base += c * st[i]; }
    let acc = R.init;
    for (let j = 0; j < x.shape[axis]; j++) acc = R.js(acc, x.data[base + j * st[axis]]);
    out.data[e] = acc;
  }
  return keep ? out : new Tensor(oshape.filter((_, i) => i !== axis), out.data);
}
// a view gathers through an index map; the map is compiled to a JS loop nest once per (map, shapes)
const VIEW_FNS = new Map();
export function viewRef(x, shape, map) {
  x = asT(x);
  const key = `${map.key()}|${shape.join("x")}|${x.shape.join("x")}`;
  let fn = VIEW_FNS.get(key);
  if (!fn) {
    const is = strides(x.shape);
    const offset = map.exprs.map((e, j) => (is[j] ? `${IX.toJs(e)} * ${is[j]}` : null)).filter(Boolean).join(" + ") || "0";
    let body = "";
    shape.forEach((d, i) => { body += `for (let a${i} = 0; a${i} < ${d}; a${i}++) `; });
    body += `out[e++] = src[${offset}];`;
    fn = new Function("src", "out", "__mod", `let e = 0; ${body}`);
    if (VIEW_FNS.size > 500) VIEW_FNS.clear();
    VIEW_FNS.set(key, fn);
  }
  const out = new Tensor(shape);
  fn(x.data, out.data, (a, b) => ((a % b) + b) % b);
  return out;
}
function matmulRef(a, b) {
  a = asT(a); b = asT(b);
  const K = a.shape.at(-1), N = b.shape.at(-1), M = a.shape.at(-2) ?? 1;
  const batch = numel(a.shape.slice(0, -2));
  const out = new Tensor([...a.shape.slice(0, -1), N]);
  const bBatched = b.shape.length > 2;
  for (let z = 0; z < batch; z++) for (let i = 0; i < M; i++) for (let j = 0; j < N; j++) {
    let s = 0;
    for (let q = 0; q < K; q++) s += a.data[z * M * K + i * K + q] * b.data[(bBatched ? z * K * N : 0) + q * N + j];
    out.data[z * M * N + i * N + j] = s;
  }
  return out;
}
const linearRef = (x, w) => { x = asT(x); w = asT(w); const N = w.shape[0], K = w.shape[1]; const wt = new Tensor([K, N]); for (let n = 0; n < N; n++) for (let q = 0; q < K; q++) wt.data[q * N + n] = w.data[n * K + q]; return matmulRef(x, wt); };
const rows = (x) => { const D = x.shape.at(-1); return [x.data.length / D, D]; };
function rmsRef(x, w, eps) { x = asT(x); w = asT(w); const [R, D] = rows(x); const o = new Tensor(x.shape); for (let r = 0; r < R; r++) { let s = 0; for (let j = 0; j < D; j++) s += x.data[r * D + j] ** 2; const inv = 1 / Math.sqrt(s / D + eps); for (let j = 0; j < D; j++) o.data[r * D + j] = x.data[r * D + j] * inv * w.data[j]; } return o; }
function lnRef(x, w, b, eps) { x = asT(x); w = asT(w); b = asT(b); const [R, D] = rows(x); const o = new Tensor(x.shape); for (let r = 0; r < R; r++) { let m = 0; for (let j = 0; j < D; j++) m += x.data[r * D + j]; m /= D; let v = 0; for (let j = 0; j < D; j++) v += (x.data[r * D + j] - m) ** 2; const inv = 1 / Math.sqrt(v / D + eps); for (let j = 0; j < D; j++) o.data[r * D + j] = (x.data[r * D + j] - m) * inv * w.data[j] + b.data[j]; } return o; }
function softmaxRef(x, dim) { x = asT(x); const ax = dim < 0 ? x.shape.length + dim : dim; const mx = reduceRef("max", x, ax); const e = ewRef("exp", [ewRef("sub", [x, mx])]); return ewRef("div", [e, reduceRef("add", e, ax)]); }
function reshapeMap(inShape, outShape) {
  return IX.map(outShape.length, (a) => {
    const os = strides(outShape), is = strides(inShape);
    let flat = IX.C(0);
    a.forEach((v, i) => { flat = flat.add(v.mul(os[i])); });
    return inShape.map((d, j) => (d === 1 ? IX.C(0) : flat.div(is[j]).mod(d)));
  });
}
export function broadcastMap(from, to) {
  const off = to.length - from.length;
  return IX.map(to.length, (a) => from.map((d, j) => (d === 1 && to[j + off] !== 1 ? IX.C(0) : a[j + off])));
}

// ----------------------------------------------------------------------------- dialects
const T_ = (shape) => k.tensor(shape);
const sameAs = ({ x }) => x.type;

export const nn = k.dialect("nn").describe("the frontend: a small PyTorch-like op set, each with reference semantics")
  .op("ew", { args: { variadic: "xs" }, attrs: { fn: "add" }, traits: ["pure"], infer: ({ xs, fn }) => (F(fn), T_(bshape(...xs.map((x) => x.type.shape)))), eval: ({ xs, fn }) => ewRef(fn, xs), print: "{fn}({xs})" })
  .op("linear", { args: ["x", "w"], infer: ({ x, w }) => T_([...x.type.shape.slice(0, -1), w.type.shape[0]]), eval: ({ x, w }) => linearRef(x, w), print: "linear({x}, {w})",
    validate: ({ args: [x, w] }) => x.type.shape.at(-1) === w.type.shape[1] || `in_features ${x.type.shape.at(-1)} ≠ weight ${w.type.shape[1]}` })
  .op("matmul", { args: ["a", "b"], infer: ({ a, b }) => T_([...a.type.shape.slice(0, -1), b.type.shape.at(-1)]), eval: ({ a, b }) => matmulRef(a, b), print: "matmul({a}, {b})" })
  .op("rms_norm", { args: ["x", "w"], attrs: { eps: 1e-6 }, infer: sameAs, eval: ({ x, w, eps }) => rmsRef(x, w, eps), print: "rms_norm({x}, {w}, eps={eps})" })
  .op("layer_norm", { args: ["x", "w", "b"], attrs: { eps: 1e-5 }, infer: sameAs, eval: ({ x, w, b, eps }) => lnRef(x, w, b, eps), print: "layer_norm({x}, {w}, {b}, eps={eps})" })
  .op("softmax", { args: ["x"], attrs: { dim: -1 }, infer: sameAs, eval: ({ x, dim }) => softmaxRef(x, dim), print: "softmax({x}, dim={dim})" })
  .op("gelu", { args: ["x"], attrs: { approximate: "tanh" }, infer: sameAs, eval: ({ x }) => ewRef("mul", [ewRef("mul", [x, 0.5]), ewRef("add", [1, ewRef("tanh", [ewRef("mul", [0.7978845608, ewRef("add", [x, ewRef("mul", [0.044715, ewRef("mul", [x, ewRef("mul", [x, x])])])])])])])]), print: "gelu({x})" })
  .op("silu", { args: ["x"], infer: sameAs, eval: ({ x }) => ewRef("mul", [x, ewRef("sigmoid", [x])]), print: "silu({x})" })
  .op("reduce", { args: ["x"], attrs: { fn: "add", axis: -1, keepdim: true }, infer: ({ x, axis, keepdim }) => { const s = x.type.shape; const a = axis < 0 ? s.length + axis : axis; return T_(keepdim ? s.map((d, i) => (i === a ? 1 : d)) : s.filter((_, i) => i !== a)); }, eval: ({ x, fn, axis, keepdim }) => reduceRef(fn, x, axis, keepdim), print: "{fn}({x}, axis={axis})" })
  .op("transpose", { args: ["x"], attrs: { d0: -2, d1: -1 }, infer: ({ x, d0, d1 }) => { const s = x.type.shape.slice(); const n = s.length; const i = d0 < 0 ? n + d0 : d0, j = d1 < 0 ? n + d1 : d1; [s[i], s[j]] = [s[j], s[i]]; return T_(s); }, eval: ({ x, d0, d1, type }) => { const n = asT(x).shape.length; const i = d0 < 0 ? n + d0 : d0, j = d1 < 0 ? n + d1 : d1; return viewRef(x, type.shape, IX.map(n, (a) => { const b = a.slice(); [b[i], b[j]] = [b[j], b[i]]; return b; })); }, print: "transpose({x}, {d0}, {d1})" })
  .op("reshape", { args: ["x"], attrs: { shape: [] }, infer: ({ x, shape }) => { if (numel(shape) !== numel(x.type.shape)) throw new KilnError("ShapeError", `reshape (${x.type.shape}) → (${shape}): sizes differ`); return T_(shape); }, eval: ({ x, shape }) => new Tensor(shape, asT(x).data.slice()), print: "reshape({x}, {shape})" })
  .op("slice", { args: ["x"], attrs: { axis: 0, start: 0, end: 1 }, infer: ({ x, axis, start, end }) => { const s = x.type.shape.slice(); const a = axis < 0 ? s.length + axis : axis; s[a] = end - start; return T_(s); }, eval: ({ x, axis, start, type }) => { const n = asT(x).shape.length; const a = axis < 0 ? n + axis : axis; return viewRef(x, type.shape, IX.map(n, (c) => c.map((v, i) => (i === a ? v.add(start) : v)))); }, print: "{x}[{axis}: {start}..{end}]" });

export const tensor = k.dialect("tensor").describe("Tensor IR: elementwise, reduction and index-map primitives")
  .op("const", { attrs: { value: 0, shape: [], data: null }, traits: ["pure", "any-ir"], infer: ({ shape, data }) => T_(data ? data.shape : shape),
    eval: ({ value, shape, data }) => (data ? data : Tensor.fill(shape, value)),
    print: ({ value, shape, data, name }) => (data ? `${name ? name + " " : ""}data(${data.shape.join("×")})` : shape.length ? `splat ${+(+value).toPrecision(6)} (${shape.join("×")})` : String(+(+value).toPrecision(6))) })
  .op("ew", { args: { variadic: "xs" }, attrs: { fn: "add" }, traits: ["pure"], infer: ({ xs }) => xs[0].type, eval: ({ xs, fn }) => ewRef(fn, xs),
    validate: ({ args }) => args.every((a) => a.type.shape.join() === args[0].type.shape.join()) || "elementwise inputs must share a shape (insert views)", print: "{fn}({xs})" })
  .op("reduce", { args: ["x"], attrs: { fn: "add", axis: -1 }, traits: ["pure"], infer: ({ x, axis }) => { const s = x.type.shape; const a = axis < 0 ? s.length + axis : axis; return T_(s.map((d, i) => (i === a ? 1 : d))); }, eval: ({ x, fn, axis }) => reduceRef(fn, x, axis), print: "{fn}({x}, axis={axis})" })
  .op("view", { args: ["x"], attrs: { shape: [], map: null }, traits: ["pure"], infer: ({ shape }) => T_(shape), eval: ({ x, shape, map }) => viewRef(x, shape, map),
    print: ({ x, map }) => `${x}[${map.exprs.map((e) => IX.print(e)).join(", ")}]` });

// constants: splat values lift to tensor.const; data constants carry a Tensor
for (const d of [nn, tensor]) d.lifts((v) => (v instanceof Tensor ? tensor.const({ data: v, shape: v.shape }) : tensor.const({ value: v, shape: [] })));

export function weight(name, shape, { seed = null, scale = null, init = "normal" } = {}) {
  const s = seed ?? [...name].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7);
  const sc = scale ?? 1 / Math.sqrt(shape.at(-1) || 1);
  const t = init === "ones" ? Tensor.fill(shape, 1) : init === "zeros" ? Tensor.fill(shape, 0) : Tensor.random(shape, { seed: s, scale: sc });
  return tensor.const({ data: t, shape, name });
}

// ----------------------------------------------------------------------------- helpers over Tensor IR
// broadcast-aware: T.add(a, b) inserts the views elementwise ops need
const cnst = (v) => tensor.const({ value: v, shape: [] });
const toV = (x) => (x instanceof Value ? x : cnst(x));
export const T = {
  c: cnst,
  bc(x, shape) { x = toV(x); const s = x.type.shape; if (s.join() === shape.join()) return x; return tensor.view(x, { shape, map: broadcastMap(s, shape) }); },
  ew(fnName, ...xs) { xs = xs.map(toV); const shape = bshape(...xs.map((x) => x.type.shape)); return tensor.ew(xs.map((x) => T.bc(x, shape)), { fn: fnName }); },
  reduce(x, fnName, axis) { return tensor.reduce(x, { fn: fnName, axis: axis < 0 ? x.type.shape.length + axis : axis }); },
  sum: (x, axis = -1) => T.reduce(x, "add", axis),
  max: (x, axis = -1) => T.reduce(x, "max", axis),
  view(x, shape, mapFn) { return tensor.view(x, { shape, map: IX.map(shape.length, mapFn) }); },
  squeeze(x, axis) { const s = x.type.shape; const a = axis < 0 ? s.length + axis : axis; return T.view(x, s.filter((_, i) => i !== a), (c) => [...c.slice(0, a), IX.C(0), ...c.slice(a)]); },
  reshape(x, shape) { return tensor.view(x, { shape, map: reshapeMap(x.type.shape, shape) }); },
};
for (const name of ["add", "sub", "mul", "div", "max", "min", "pow", "exp", "log", "sqrt", "rsqrt", "tanh", "sigmoid", "relu", "neg", "abs", "square", "recip", "gt", "lt", "select", "sin", "cos"]) {
  if (!T[name]) T[name] = (...xs) => T.ew(name, ...xs);
}
T.maximum = (a, b) => T.ew("max", a, b);

// nn-level conveniences for writing programs: x.add(y), x.matmul(w), x.softmax()
const nv = (x) => (x instanceof Value ? x : tensor.const({ value: x, shape: [] }));
export const N = {
  ew: (f, ...xs) => nn.ew(xs.map(nv), { fn: f }),
  add: (a, b) => N.ew("add", a, b), sub: (a, b) => N.ew("sub", a, b), mul: (a, b) => N.ew("mul", a, b), div: (a, b) => N.ew("div", a, b),
  max: (a, b) => N.ew("max", a, b), min: (a, b) => N.ew("min", a, b), pow: (a, b) => N.ew("pow", a, b),
  exp: (x) => N.ew("exp", x), log: (x) => N.ew("log", x), sqrt: (x) => N.ew("sqrt", x), rsqrt: (x) => N.ew("rsqrt", x), tanh: (x) => N.ew("tanh", x),
  sigmoid: (x) => N.ew("sigmoid", x), relu: (x) => N.ew("relu", x), abs: (x) => N.ew("abs", x), neg: (x) => N.ew("neg", x), square: (x) => N.ew("square", x),
  sin: (x) => N.ew("sin", x), cos: (x) => N.ew("cos", x), select: (c, a, b) => N.ew("select", c, a, b), gt: (a, b) => N.ew("gt", a, b), lt: (a, b) => N.ew("lt", a, b),
  sum: (x, axis = -1, keepdim = true) => nn.reduce(x, { fn: "add", axis, keepdim }),
  amax: (x, axis = -1, keepdim = true) => nn.reduce(x, { fn: "max", axis, keepdim }),
  mean: (x, axis = -1, keepdim = true) => N.mul(N.sum(x, axis, keepdim), 1 / x.type.shape.at(axis < 0 ? axis : axis)),
  linear: (x, w, b) => (b ? N.add(nn.linear(x, w), b) : nn.linear(x, w)),
  matmul: (a, b) => nn.matmul(a, b),
  rms_norm: (x, w, o = {}) => nn.rms_norm(x, w, o), layer_norm: (x, w, b, o = {}) => nn.layer_norm(x, w, b, o),
  softmax: (x, dim = -1) => nn.softmax(x, { dim }), gelu: (x) => nn.gelu(x), silu: (x) => nn.silu(x),
  transpose: (x, d0 = -2, d1 = -1) => nn.transpose(x, { d0, d1 }), reshape: (x, shape) => nn.reshape(x, { shape }),
  slice: (x, axis, start, end) => nn.slice(x, { axis, start, end }),
  weight, const: (v, shape = []) => tensor.const({ value: v, shape }),
};
nn.methods({
  add: (a, b) => N.add(a, b), sub: (a, b) => N.sub(a, b), mul: (a, b) => N.mul(a, b), div: (a, b) => N.div(a, b), pow: (a, b) => N.pow(a, b),
  exp: (a) => N.exp(a), log: (a) => N.log(a), tanh: (a) => N.tanh(a), relu: (a) => N.relu(a), sigmoid: (a) => N.sigmoid(a), sqrt: (a) => N.sqrt(a), neg: (a) => N.neg(a), square: (a) => N.square(a),
  sum: (a, ax, kd) => N.sum(a, ax, kd), mean: (a, ax, kd) => N.mean(a, ax, kd), amax: (a, ax, kd) => N.amax(a, ax, kd),
  matmul: (a, b) => N.matmul(a, b), linear: (a, w, b) => N.linear(a, w, b), softmax: (a, d) => N.softmax(a, d), t: (a) => N.transpose(a), reshape: (a, s) => N.reshape(a, s),
  gelu: (a) => N.gelu(a), silu: (a) => N.silu(a),
});
tensor.methods({ add: (a, b) => T.add(a, b), sub: (a, b) => T.sub(a, b), mul: (a, b) => T.mul(a, b), div: (a, b) => T.div(a, b), exp: (a) => T.exp(a), sum: (a, ax) => T.sum(a, ax), max: (a, ax) => T.max(a, ax) });

// ----------------------------------------------------------------------------- d: decomposition
// k-style "decompose" rules: a rule per frontend op whose lambda builds Tensor IR. Every node it
// builds is stamped with origin = the op it came from (provenance for kernel names).
export function decompose(opName, build, name = "decompose:" + opName) {
  return k.rule(name).match(P.op(opName).as("n")).rewrite((ctx) => {
    const n = ctx.n;
    const before = new Set(ctx.graph.nodes.keys());
    const args = n.def.variadic ? { [n.def.variadic]: n.args } : Object.fromEntries(n.def.argNames.map((a, i) => [a, n.args[i]]));
    const out = build({ ...n.attrs, ...args, out: n, node: n, T, skip: ctx.skip });
    // provenance: tag what this rewrite created
    const g = ctx.graph;
    const origin = n.attrs.origin || opName.replace(/^nn\./, "");
    for (const [id, node] of [...g.nodes]) if (!before.has(id) && !node.attrs.origin && node.def !== tensor.const.def) g.nodes.set(id, new Node(id, node.def, node.args, { ...node.attrs, origin }, node.type, node.knobs));
    g.touch();
    return out;
  });
}
const lastAxis = (x, a) => (a < 0 ? x.type.shape.length + a : a);
export const decompositions = [
  decompose("nn.ew", ({ xs, fn }) => T.ew(fn, ...xs)),
  decompose("nn.linear", ({ x, w, out }) => {
    const xs = x.type.shape, K = xs.at(-1), Nn = w.type.shape[0], B = xs.slice(0, -1);
    const a = T.view(x, [...B, K, Nn], (c) => [...c.slice(0, B.length), c[B.length]]);
    const b = T.view(w, [...B, K, Nn], (c) => [c[B.length + 1], c[B.length]]);
    const s = T.sum(tensor.ew([a, b], { fn: "mul" }), -2);
    return T.view(s, out.type.shape, (c) => [...c.slice(0, B.length), IX.C(0), c[B.length]]);
  }),
  decompose("nn.matmul", ({ a, b, out }) => {
    const as = a.type.shape, bs = b.type.shape, K = as.at(-1), Nn = bs.at(-1), B = as.slice(0, -1);
    const A = T.view(a, [...B, K, Nn], (c) => [...c.slice(0, B.length), c[B.length]]);
    const Bm = T.view(b, [...B, K, Nn], (c) => (bs.length === 2 ? [c[B.length], c[B.length + 1]] : [...c.slice(0, B.length - 1), c[B.length], c[B.length + 1]]));
    const s = T.sum(tensor.ew([A, Bm], { fn: "mul" }), -2);
    return T.view(s, out.type.shape, (c) => [...c.slice(0, B.length), IX.C(0), c[B.length]]);
  }),
  decompose("nn.rms_norm", ({ x, w, eps }) => {
    const D = x.type.shape.at(-1);
    const ms = T.div(T.sum(T.mul(x, x), -1), D);
    return T.mul(T.mul(x, T.rsqrt(T.add(ms, eps))), w);
  }),
  decompose("nn.layer_norm", ({ x, w, b, eps }) => {
    const D = x.type.shape.at(-1);
    const xc = T.sub(x, T.div(T.sum(x, -1), D));
    const inv = T.rsqrt(T.add(T.div(T.sum(T.mul(xc, xc), -1), D), eps));
    return T.add(T.mul(T.mul(xc, inv), w), b);
  }),
  decompose("nn.softmax", ({ x, dim }) => {
    const a = lastAxis(x, dim);
    const e = T.exp(T.sub(x, T.max(x, a)));
    return T.div(e, T.sum(e, a));
  }),
  decompose("nn.gelu", ({ x }) => T.mul(T.mul(x, 0.5), T.add(1, T.tanh(T.mul(0.7978845608, T.add(x, T.mul(0.044715, T.mul(x, T.mul(x, x))))))))),
  decompose("nn.silu", ({ x }) => T.mul(x, T.sigmoid(x))),
  decompose("nn.reduce", ({ x, fn, axis, keepdim }) => { const r = T.reduce(x, fn, lastAxis(x, axis)); return keepdim ? r : T.squeeze(r, lastAxis(x, axis)); }),
  decompose("nn.transpose", ({ x, d0, d1, out }) => { const n = x.type.shape.length; const i = lastAxis(x, d0), j = lastAxis(x, d1); return T.view(x, out.type.shape, (c) => { const b = c.slice(); [b[i], b[j]] = [b[j], b[i]]; return b; }); }),
  decompose("nn.reshape", ({ x, shape }) => T.reshape(x, shape)),
  decompose("nn.slice", ({ x, axis, start, out }) => { const a = lastAxis(x, axis); return T.view(x, out.type.shape, (c) => c.map((v, i) => (i === a ? v.add(start) : v))); }),
];
export const decomposition = k.pass("frontend/decomposition").short("d").rules(...decompositions).helpers("tensor", T)
  .describe("each nn op becomes elementwise, reduction and index-map primitives");

// ----------------------------------------------------------------------------- o: optimization
const isSplat = (v) => v.is("tensor.const") && !v.attrs.data;
export const composeViews = k.rule("compose_views")
  .match(P.chain(P.op("tensor.view").as("p"), P.op("tensor.view").as("c")))
  .rewrite(({ p, c }) => tensor.view(p.arg("x"), { shape: c.attrs.shape, map: IX.compose(p.attrs.map, c.attrs.map), origin: c.attrs.origin }));
export const foldSplatView = k.rule("fold_splat_view")
  .match(P.op("tensor.view").as("v").where(({ v }) => isSplat(v.arg("x"))))
  .rewrite(({ v }) => tensor.const({ value: v.arg("x").attrs.value, shape: v.attrs.shape }));
export const dropIdentityView = k.rule("drop_identity_view")
  .match(P.op("tensor.view").as("v").where(({ v }) => v.attrs.map.isIdentity(v.arg("x").type.shape.length) && v.arg("x").type.shape.join() === v.attrs.shape.join()))
  .rewrite(({ v }) => v.arg("x"));
export const foldSplatEw = k.rule("fold_splat_ew")
  .match(P.op("tensor.ew").as("e").where(({ e }) => e.args.every(isSplat)))
  .rewrite(({ e }) => tensor.const({ value: F(e.attrs.fn).js(...e.args.map((a) => a.attrs.value)), shape: e.type.shape }));
// a·b + c → fma(a, b, c): one instruction, one rounding (what nvcc does by default with -fmad=true)
export const contractFma = k.rule("contract_fma")
  .match(P.op("tensor.ew").as("e").where(({ e }) => e.attrs.fn === "add" && e.args.length === 2 && e.args.some((a) => a.is(tensor.ew) && a.attrs.fn === "mul" && a.args.length === 2 && a.users.length === 1)))
  .rewrite(({ e }) => {
    const j = e.args.findIndex((a) => a.is(tensor.ew) && a.attrs.fn === "mul" && a.args.length === 2 && a.users.length === 1);
    const m = e.arg(j), c = e.arg(1 - j);
    return tensor.ew([m.arg(0), m.arg(1), c], { fn: "fma", ...(e.attrs.origin ? { origin: e.attrs.origin } : {}) });
  });
export const optimization = k.pass("frontend/optimization").short("o").rules(composeViews, foldSplatView, dropIdentityView, foldSplatEw, contractFma)
  .describe("compose index-map chains, fold constant views and constant arithmetic, contract multiply-add into fma");

export { asT, ewRef, reduceRef, matmulRef };
